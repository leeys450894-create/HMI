//API_SocketControl.cpp

#include "stdafx.h"
#include "SocketControl.h"

#include "SocketCtrlManager.h"


//=====================================================================
// Export�Ǵ� ��� �Լ� �ڵ忡 AFX_MANAGE_STATE ��ũ�� �ݵ�� ������ ��
// �����尣�� ��ȣ�� ���� �� �ִ�.
// Export���� �ʴ� �Լ��� AFX_MANAGE_STATE�� �� �ʿ� ����
// Export�Ǵ� �Լ��� �ݵ�� ��� ���� �Լ� �̸� �߰��ؾ� .def ���� ����
// 
// Created by Jay Hong : 2009.04.28
//=====================================================================

#define dfMAX_INDEX  30		// �ִ� Socket 30������ ����	// jsyoon 20160406 change 24 to 30

//=====================================================================
// g_SocketCtrlManager�� Global�� ���� �Ǿ� �ֱ� ������ �迭 ���·� ����
// �����ܿ����� nIdex�� �̿��Ͽ� g_SocketCtrlManager[nIndex] ��밡��
// 
// Modified by Jay Hong : 2009.05.01 (�ٷ����� ������ ����ؼ� ���Ѵ�!!!!)
//=====================================================================
CSocketCtrlManager g_SocketCtrlManager[dfMAX_INDEX];

BOOL WINAPI api_SocketCtrl_Initialize(UINT nIdex, CWnd *pParentWnd, int nServer, UINT nPort, TCHAR* szIPAddress /*CString szIPAddress = "127.0.0.1"*/)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());

	if(nIdex >= dfMAX_INDEX || nIdex<0)
	{
		AfxMessageBox("(Socket Manager) Out of range... ");
		return FALSE;
	}

	CString strIP;
	strIP.Format("%s", szIPAddress);

	if(!g_SocketCtrlManager[nIdex].m_bCreated)
	{
		g_SocketCtrlManager[nIdex].Create(pParentWnd);

		return g_SocketCtrlManager[nIdex].Initialize(pParentWnd, nServer, nPort, strIP);
	}
	else
	{
		return g_SocketCtrlManager[nIdex].Initialize(pParentWnd, nServer, nPort, strIP);
	}

	AfxMessageBox("(Socket Manager) Create Fail... ");

	return FALSE;
}

BOOL	WINAPI	api_SocketCtrl_Close(UINT nIdex)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());

	if(g_SocketCtrlManager[nIdex].m_bCreated)
	{
		return g_SocketCtrlManager[nIdex].Close();
	}

	return FALSE;
}

void WINAPI api_SocketCtrl_GetLocalIP(UINT nIdex, TCHAR* szIPAddress)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());

	CString strIp;

	if(g_SocketCtrlManager[nIdex].m_bCreated)
	{
		strIp.Format("%s", g_SocketCtrlManager[nIdex].m_pNetWallTalk->GetLocalIP());
	}
	else
	{
		strIp.Format("%s", "127.0.0.1");
	}

	int iLength = 0;
	iLength = strIp.GetLength();
	memcpy(szIPAddress, strIp, sizeof(char)*iLength);

//	return "127.0.0.1";
}

void WINAPI api_SocketCtrl_GetServerIPAddress(UINT nIdex, TCHAR* szIPAddress)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());

	CString strIp;

	if(g_SocketCtrlManager[nIdex].m_bCreated)
	{
		if( g_SocketCtrlManager[nIdex].m_pNetWallTalk != NULL )
			strIp.Format("%s", g_SocketCtrlManager[nIdex].m_pNetWallTalk->GetServerIPAddress());
		else
			strIp.Format("%s", g_SocketCtrlManager[nIdex].m_pClient->GetServerIPAddress());
	}
	else
	{
		strIp.Format("%s", "127.0.0.1");
	}

	int iLength = 0;
	iLength = strIp.GetLength();
	memcpy(szIPAddress, strIp, sizeof(char)*iLength);

//	return "127.0.0.1";
}

void WINAPI api_SocketCtrl_GetClientIPAddress(UINT nIdex, TCHAR* szIPAddress)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());

	CString strIp;

	if(g_SocketCtrlManager[nIdex].m_bCreated)
	{
		if( g_SocketCtrlManager[nIdex].m_pNetWallTalk != NULL )
			strIp.Format("%s", g_SocketCtrlManager[nIdex].m_pNetWallTalk->GetClientIPAddress());
		else
			strIp.Format("%s", g_SocketCtrlManager[nIdex].m_pClient->GetClientIPAddress());


	}
	else
	{
		strIp.Format("%s", "127.0.0.1");
	}
	
	int iLength = 0;
	iLength = strIp.GetLength();
	memcpy(szIPAddress, strIp, sizeof(char)*iLength);

//	return "127.0.0.1";
}

int WINAPI api_SocketCtrl_SendData(UINT nIdex, BYTE *pSendData, UINT nDataSize)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());

	if(g_SocketCtrlManager[nIdex].m_bCreated)
	{
		return g_SocketCtrlManager[nIdex].SendData(pSendData, nDataSize);
	}

	return -1;
}

int	WINAPI	api_SocketCtrl_GetReceiveData(UINT nIdex, BYTE *pData, UINT nBufSize)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());

	if(g_SocketCtrlManager[nIdex].m_bCreated)
	{
		return g_SocketCtrlManager[nIdex].GetReceiveData(pData, nBufSize);
	}

	return 0;
}

UINT WINAPI  api_SocketCtrl_GetClientPort(UINT nIdex)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());

	if(g_SocketCtrlManager[nIdex].m_bCreated)
	{
		return g_SocketCtrlManager[nIdex].m_pNetWallTalk->GetClientPort();
	}
	
	return 0;
}

UINT WINAPI	api_SocketCtrl_GetReceiveDataSize(UINT nIdex)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());
	
	if(g_SocketCtrlManager[nIdex].m_bCreated)
	{
		return g_SocketCtrlManager[nIdex].GetReceiveDataSize();
	}

	return 0;
}

UINT WINAPI	api_SocketCtrl_GetServerPort(UINT nIdex)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());

	if(g_SocketCtrlManager[nIdex].m_bCreated)
	{
		return g_SocketCtrlManager[nIdex].m_pNetWallTalk->GetServerPort();
	}

	return 0;
}


BOOL WINAPI	api_SocketCtrl_IsConnected(UINT nIdex)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());

	if(g_SocketCtrlManager[nIdex].m_bCreated)
	{

		return g_SocketCtrlManager[nIdex].IsConnected();
	}

	return FALSE;
}


BOOL WINAPI	api_SocketCtrl_SetModeChange(UINT nIdex, BOOL bIsServer)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());

	if(g_SocketCtrlManager[nIdex].m_bCreated)
	{
		return g_SocketCtrlManager[nIdex].m_pNetWallTalk->SetModeChange(bIsServer);
	}

	return FALSE;
}


BOOL WINAPI	api_SocketCtrl_SetServerIPAddress(UINT nIdex, CString sIPAddress)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());

	if(g_SocketCtrlManager[nIdex].m_bCreated)
	{
		return g_SocketCtrlManager[nIdex].m_pNetWallTalk->SetServerIPAddress(sIPAddress);
	}

	return FALSE;
}

BOOL WINAPI	api_SocketCtrl_SetServerPort(UINT nIdex, UINT nPort)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());

	if(g_SocketCtrlManager[nIdex].m_bCreated)
	{
		return g_SocketCtrlManager[nIdex].m_pNetWallTalk->SetServerPort(nPort);
	}

	return FALSE;
}

