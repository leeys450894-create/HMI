#if !defined(AFX_API_MCCR_H__D17C24DF_1D38_489C_B7B3_634EC901EE48__INCLUDED_)
#define AFX_API_MCCR_H__D17C24DF_1D38_489C_B7B3_634EC901EE48__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#include "..\\include\SheardDefineMCC.h"
#endif // _MSC_VER > 1000
// API_MCC_REPORT.h : header file
//

void WINAPI API_MCCR_Initialize(HWND hParentWnd, CRect r);
void WINAPI API_MCCR_KillThred();
void WINAPI API_MCCR_FinalizeReport();
void WINAPI API_MCCR_SetLogPath(CString str);
void WINAPI API_MCCR_SetConfigPath(CString str);
CWnd* WINAPI API_MCCR_GetReportmWnd();
int WINAPI API_MCCR_AddQueue(int iFlag);
VTM_MCC* WINAPI API_MCCR_GetSharedMemory();

#endif // !defined(AFX_API_MCCR_H__D17C24DF_1D38_489C_B7B3_634EC901EE48__INCLUDED_)
