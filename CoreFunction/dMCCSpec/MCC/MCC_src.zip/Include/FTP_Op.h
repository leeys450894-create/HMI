#if !defined(AFX_FTP_OP_H__9B552D44_03DF_4DFF_AC7C_873D6CC17A2E__INCLUDED_)
#define AFX_FTP_OP_H__9B552D44_03DF_4DFF_AC7C_873D6CC17A2E__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// FTP_Op.h : header file
//
#include <afxinet.h>		// 1. FTP�� ���� header file include

/////////////////////////////////////////////////////////////////////////////
// CFTP_Op window

class AFX_EXT_CLASS CFTP_Op : public CWnd
{
// Construction
public:
	CFTP_Op();

// Attributes
public:
	CInternetSession session;
	CFtpConnection *connect;

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFTP_Op)
	//}}AFX_VIRTUAL

// Implementation
public:
	int FileSearchFTP(char *ip, char *user, char *pass, int port, bool flag, char *filename, char *name);
	int DeleteByFTP(char *);
	void MoveByFTP(char *source, char *destination);
	int GetFileFromFTP(char* source, char* destination);
	void CloseFTPConnection();
	int SendFileToFTP(char* source, char* destination);
	int ConnectToFTP(char* ip, char* user, char* pass, int port, bool flag);
	BOOL GetAllFileFromFTP(char *ip, char *user, char *pass, int port, bool flag, CString Source, CString destination);		// pwk 20130829 test
	virtual ~CFTP_Op();

	// Generated message map functions
protected:
	//{{AFX_MSG(CFTP_Op)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FTP_OP_H__9B552D44_03DF_4DFF_AC7C_873D6CC17A2E__INCLUDED_)
