
// MCCLogDlg.h : header file
//

#pragma once
#include "..\include\SheardDefineMCC.h"
#include "..\include\CommonFunc.h"

#define WM_MCC_ADDQUEUE		(WM_USER + 5000)
#define WM_TRAYICON_MSG		(WM_USER + 5001)

#define RUNKEY				_T("SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run")
#define AUTORUN_VALUENAME	_T("ICPTOOLS")
#define AUTORUN_ADDARGU		_T("/User")

// CMCCLogDlg dialog
class CMCCLogDlg : public CDialogEx
{
// Construction
public:
	LRESULT OnMccQueue(WPARAM wParam, LPARAM lParam);

	CMCCLogDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	enum { IDD = IDD_MCCLog_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support


// Implementation
protected:
	VTM_MCC* m_pSharedMCC;	//To Use Shared Memory Pointer
	HICON m_hIcon;

	// Generated message map functions
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnDestroy();

	int SetAddMccQueue(int iFlag);
	void GetConfig();
	void ResTrayIcon();
	BOOL SHRegDeleteValue(HKEY hKey, LPCTSTR lpKey, LPCTSTR lpValue);
	BOOL SHRegWriteString(HKEY hKey, LPCTSTR lpKey, LPCTSTR lpValue, LPCTSTR lpData);
	BOOL SHRegReadString(HKEY hKey, LPCTSTR lpKey, LPCTSTR lpValue, LPCTSTR lpDefault, LPTSTR lpRet, DWORD nSize);
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	LRESULT TrayIconMSG(WPARAM wParam, LPARAM lParam);
	void CloseDialog();

	BOOL m_bTrayIcon;
	afx_msg void OnMenuitemWindowstartautorun();
	afx_msg void OnMenuitemOpen();
	afx_msg void OnMenuitemExit();
	afx_msg void OnTimer(UINT_PTR nIDEvent);
	virtual void OnCancel();
};
