
// MCCLogDlg.cpp : implementation file
//

#include "stdafx.h"
#include "MCCLog.h"
#include "MCCLogDlg.h"
#include "afxdialogex.h"
#include "..\include\API_MCC_REPORT.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

// CAboutDlg dialog used for App About

class CAboutDlg : public CDialogEx
{
public:
	CAboutDlg();

// Dialog Data
	enum { IDD = IDD_ABOUTBOX };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

// Implementation
protected:
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialogEx(CAboutDlg::IDD)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialogEx)
END_MESSAGE_MAP()


// CMCCLogDlg dialog




CMCCLogDlg::CMCCLogDlg(CWnd* pParent /*=NULL*/)
	: CDialogEx(CMCCLogDlg::IDD, pParent)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);

	m_pSharedMCC = NULL;
	m_pSharedMCC = ::API_MCCR_GetSharedMemory();
}

void CMCCLogDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CMCCLogDlg, CDialogEx)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_WM_DESTROY()
	ON_MESSAGE(WM_MCC_ADDQUEUE,	   OnMccQueue)
	ON_MESSAGE(WM_TRAYICON_MSG, TrayIconMSG)
	ON_COMMAND(ID_MENUITEM_WINDOWSTARTAUTORUN, &CMCCLogDlg::OnMenuitemWindowstartautorun)
	ON_COMMAND(ID_MENUITEM_OPEN, &CMCCLogDlg::OnMenuitemOpen)
	ON_COMMAND(ID_MENUITEM_EXIT, &CMCCLogDlg::OnMenuitemExit)
	ON_WM_TIMER()
END_MESSAGE_MAP()


// CMCCLogDlg message handlers

BOOL CMCCLogDlg::OnInitDialog()
{
	CDialogEx::OnInitDialog();
	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		BOOL bNameValid;
		CString strAboutMenu;
		bNameValid = strAboutMenu.LoadString(IDS_ABOUTBOX);
		ASSERT(bNameValid);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

	// TODO: Add extra initialization here

//	CRect		rcWorkArea(0,90,1178,965), r2, rect;
	CRect		rcWorkArea(0,0,1920,1050), r2, rect;
	MoveWindow(rcWorkArea);

//	GetDlgItem(IDC_CTTEXTCTRL_LOG_TITLE)->GetWindowRect(&r2);
	GetDlgItem(IDC_STATIC_POS)->GetWindowRect(&r2);
	ScreenToClient(&r2);
//	r2.top += (r2.Height() + 2);
	r2.bottom = rcWorkArea.bottom;
	r2.right = rcWorkArea.right;

	// sy.kim 20171020 add
	gf_Initialize();

	GetConfig();

	::API_MCCR_Initialize(GetSafeHwnd(), r2);

	::API_MCCR_GetReportmWnd()->ShowWindow(SW_SHOW);

// 	CString strLog;
// 	strLog.Format("OnClickBtn: MCC LOG");
// 	gLog(m_pSystem->hLog, strLog, LOG_LEVEL_O);

	m_bTrayIcon = FALSE; 
	ResTrayIcon();

	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CMCCLogDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialogEx::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CMCCLogDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialogEx::OnPaint();
	}
}

// The system calls this function to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CMCCLogDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}



void CMCCLogDlg::OnDestroy()
{
	CDialogEx::OnDestroy();

	::API_MCCR_FinalizeReport();
	::API_MCCR_KillThred();
}

int CMCCLogDlg::SetAddMccQueue(int iFlag)
{
	::API_MCCR_AddQueue(iFlag);
	return 0;
}

LRESULT CMCCLogDlg::OnMccQueue(WPARAM wParam, LPARAM lParam)
{
	SetAddMccQueue(lParam);

	return 0;
}

void CMCCLogDlg::GetConfig()
{
	TCHAR szValue[MAX_PATH];
	ZeroMemory(szValue,MAX_PATH);

	CString szConfigFile;
	szConfigFile = gf_GetFilePath(dfDEFAULT_CONFIG_MCC_FILE_PATH);

	CString str;
	CString strRecipePath, strMCCLogPath;

	str = _T("MCC");
	GetPrivateProfileString (str,_T("USABLE"),_T("1"), szValue, 2, szConfigFile);
// 	if (szValue[0] == '1')
// 	{
// 		m_pSharedMCC->m_bMccTransferOn = TRUE;
// 	}
// 	else
// 	{
// 		m_pSharedMCC->m_bMccTransferOn = FALSE;
// 	}	

	GetPrivateProfileString (str,_T("EQTYPE"),_T("0"),szValue,MAX_PATH,szConfigFile);
	m_pSharedMCC->nEQType = _ttoi(szValue);

	GetPrivateProfileString (str,_T("USABLE"),_T("1"),szValue,MAX_PATH,szConfigFile);
	m_pSharedMCC->bMCCTransfer = _ttoi(szValue);

	GetPrivateProfileString (str,_T("UPLOAD_TIME"),_T("10"),szValue,MAX_PATH,szConfigFile);
	m_pSharedMCC->uMCCUploadTime = _ttoi(szValue);

	GetPrivateProfileString (str,_T("MODULEID"),_T("ELLU"),szValue,MAX_PATH,szConfigFile);
	_tcscpy_s(m_pSharedMCC->stMCCInfoEQ.szModuleID,_countof(m_pSharedMCC->stMCCInfoEQ.szModuleID), szValue);

	GetPrivateProfileString (str,_T("POSITION_FROM"),_T("A3EVP01T_TM"),szValue,MAX_PATH,szConfigFile);
	_tcscpy_s(m_pSharedMCC->stMCCInfoEQ.szEquipFromName,_countof(m_pSharedMCC->stMCCInfoEQ.szEquipFromName), szValue);

	GetPrivateProfileString (str,_T("POSITION_TO"),_T("A3EVP01T_PM"),szValue,MAX_PATH,szConfigFile);
	_tcscpy_s(m_pSharedMCC->stMCCInfoEQ.szEquipToName,_countof(m_pSharedMCC->stMCCInfoEQ.szEquipToName), szValue);

	str = _T("DIR");
	GetPrivateProfileString (str,_T("LOG"),_T("C:\\KMAC_MH"),szValue,MAX_PATH,szConfigFile);
	strRecipePath.Format(_T("%s"),szValue); 
	strMCCLogPath.Format(_T("%s%s"), strRecipePath, dfDEFAULT_MCC_FILE_PATH);
	gf_MakeDir(strMCCLogPath);

	::API_MCCR_SetLogPath(strMCCLogPath);
	::API_MCCR_SetConfigPath(g_sAppPath);
}

BOOL CMCCLogDlg::PreTranslateMessage(MSG* pMsg)
{
	switch( pMsg->wParam )
	{
	case VK_ESCAPE:
		return TRUE;
	case VK_RETURN:
		return TRUE;
	}

	return CDialogEx::PreTranslateMessage(pMsg);
}

void CMCCLogDlg::ResTrayIcon()
{
	NOTIFYICONDATA nid;
	nid.cbSize = sizeof(nid);
	nid.hWnd = m_hWnd;
	nid.uID = IDI_TRAYICON;
	nid.uFlags = NIF_MESSAGE | NIF_ICON | NIF_TIP;
	nid.uCallbackMessage = WM_TRAYICON_MSG;
	nid.hIcon = AfxGetApp()->LoadIcon(IDI_TRAYICON); 

	lstrcpy(nid.szTip,_T("HBS MCC TOOLS"));
	Shell_NotifyIcon(NIM_ADD, &nid);

	SendMessage(WM_SETICON, (WPARAM)TRUE, (LPARAM)nid.hIcon);
	m_bTrayIcon = TRUE;
}

LRESULT CMCCLogDlg::TrayIconMSG(WPARAM wParam, LPARAM lParam)
{
	switch(lParam)
	{
	case WM_LBUTTONDBLCLK:
		{ 
			NOTIFYICONDATA nid;

			nid.cbSize = sizeof(NOTIFYICONDATA);
			nid.hWnd = this->m_hWnd;
			nid.uID = 0;
			Shell_NotifyIcon(NIM_DELETE, &nid);

			ShowWindow(SW_RESTORE);
			SetForegroundWindow();
		}
		break;
	case WM_RBUTTONDOWN:     
		{
			CPoint ptMouse;
			::GetCursorPos(&ptMouse);

			TCHAR szStr[MAX_PATH*3]={0};
			CMenu menu;
			menu.LoadMenu(IDR_MENU_TRAYICON);			
			CMenu *pMenu = menu.GetSubMenu(0);

			if(SHRegReadString(HKEY_CURRENT_USER, RUNKEY, AUTORUN_VALUENAME, _T(""), szStr, MAX_PATH*2))
			{
				CString str, strTmp;
				str=szStr;
				str.TrimLeft();
				str.TrimRight();

				if(str.GetLength() > 0)
				{
					if(str.GetAt(0)=='\"') str.Delete(0);

					// 					int index1=str.Find(' ');
					// 					str.Delete(index1-1, str.GetLength()+1-index1);
					int index1=str.Find(_T(".exe"));
					strTmp = str.Left(index1+4);
				}

			//	if(strTmp.CompareNoCase(__argv[0])==0)
				if(strTmp.CompareNoCase(__wargv[0])==0)
				{
					pMenu->CheckMenuItem(ID_MENUITEM_WINDOWSTARTAUTORUN, MF_CHECKED);
				}
			}			
			pMenu->TrackPopupMenu(TPM_LEFTALIGN | TPM_RIGHTBUTTON, ptMouse.x, ptMouse.y, AfxGetMainWnd());
		}
	}
	return 0;
}

BOOL CMCCLogDlg::SHRegReadString(HKEY hKey, LPCTSTR lpKey, LPCTSTR lpValue, LPCTSTR lpDefault, LPTSTR lpRet, DWORD nSize)
{
	HKEY key;	
	DWORD dwDisp;	
	DWORD Size;	
	BOOL bRet = FALSE;	

	if(RegCreateKeyEx(hKey, lpKey, 0, NULL, REG_OPTION_NON_VOLATILE, KEY_READ, NULL, &key, &dwDisp) != ERROR_SUCCESS)		
	{		
		return FALSE;		
	}	

	Size = nSize;

	if(RegQueryValueEx(key, lpValue, 0, NULL,(LPBYTE)lpRet, &Size) != ERROR_SUCCESS)		
	{		
		lstrcpy(lpRet, lpDefault);		
	}	
	else		
	{		
		bRet = TRUE;		
	}	

	RegCloseKey(key);

	return bRet;
}

BOOL CMCCLogDlg::SHRegWriteString(HKEY hKey, LPCTSTR lpKey, LPCTSTR lpValue, LPCTSTR lpData)
{
	HKEY  key;
	DWORD dwDisp;

	if(RegCreateKeyEx(hKey, lpKey,0,NULL, REG_OPTION_NON_VOLATILE, KEY_WRITE,NULL,&key,&dwDisp)!=ERROR_SUCCESS) 
		return FALSE;

	if(RegSetValueEx(key, lpValue,0,REG_SZ,(LPBYTE)lpData,_tcsclen(lpData)+1)!=ERROR_SUCCESS) 
		return FALSE;

	RegCloseKey(key);

	return TRUE;
}

BOOL CMCCLogDlg::SHRegDeleteValue(HKEY hKey, LPCTSTR lpKey, LPCTSTR lpValue)
{
	HKEY  key;

	if(RegOpenKeyEx(hKey, lpKey, 0, KEY_ALL_ACCESS, &key)!=ERROR_SUCCESS) 
		return FALSE;

	if(RegDeleteValue(key, lpValue)!=ERROR_SUCCESS) 
		return FALSE;

	RegCloseKey(key);

	return TRUE;
}

void CMCCLogDlg::OnMenuitemWindowstartautorun()
{
	CString strWrite;
	TCHAR    szStr[MAX_PATH*3]={0};

	if(SHRegReadString(HKEY_CURRENT_USER, RUNKEY, AUTORUN_VALUENAME, _T(" "), szStr, MAX_PATH*2))
	{
		CString str, strTmp;
		str=szStr;
		str.TrimLeft();
		str.TrimRight();
		if (str.GetLength() > 0)
		{
			if (str.GetAt(0)=='\"') str.Delete(0);

			//			int index1=str.Find(' ');
			//			str.Delete(index1-1, str.GetLength()+1-index1);			
			int index1=str.Find(_T(".exe"));
			strTmp = str.Left(index1+4);
		}

	//	if(strTmp.CompareNoCase(__argv[0])!=0)
		if(strTmp.CompareNoCase(__wargv[0])!=0)
		{
			strWrite="\""; 
			strWrite+= __wargv[0];
			strWrite+= "\" ";
			strWrite+= AUTORUN_ADDARGU;
			SHRegWriteString(HKEY_CURRENT_USER, RUNKEY, AUTORUN_VALUENAME, strWrite);
			AfxMessageBox(_T("SHRegWriteString"));
		}
		else
		{
			SHRegDeleteValue(HKEY_CURRENT_USER, RUNKEY, AUTORUN_VALUENAME);
		}
	}
	else
	{
		strWrite="\""; 
		strWrite+= __wargv[0];
		strWrite+= "\" ";
		strWrite+= AUTORUN_ADDARGU;
		SHRegWriteString(HKEY_CURRENT_USER, RUNKEY, AUTORUN_VALUENAME, strWrite);
	}
}


void CMCCLogDlg::OnMenuitemOpen()
{
	NOTIFYICONDATA nid;

	nid.cbSize = sizeof(NOTIFYICONDATA);
	nid.hWnd = this->m_hWnd;
	nid.uID = 0;
	Shell_NotifyIcon(NIM_DELETE, &nid);

	ShowWindow(SW_RESTORE);
	SetForegroundWindow();
}


void CMCCLogDlg::OnMenuitemExit()
{
	if( AfxMessageBox(_T("���α׷��� �����Ͻðڽ��ϱ�?"), MB_YESNO|MB_ICONQUESTION) != IDYES)
	{
		return;
	}
	else
	{
		NOTIFYICONDATA  nid;
		nid.cbSize = sizeof(nid);
		nid.hWnd = m_hWnd;
		nid.uID = IDI_TRAYICON;	
		Shell_NotifyIcon(NIM_DELETE, &nid);

		SetTimer(103, 3000, NULL);
	}
}

void CMCCLogDlg::CloseDialog()
{
	CDialogEx::OnOK();
}

void CMCCLogDlg::OnTimer(UINT_PTR nIDEvent)
{
	if( nIDEvent == 103 )
	{
		KillTimer(103);
		CloseDialog();;
	}

	CDialogEx::OnTimer(nIDEvent);
}

void CMCCLogDlg::OnCancel()
{
	ShowWindow(SW_HIDE);

	//CDialogEx::OnCancel();
}
