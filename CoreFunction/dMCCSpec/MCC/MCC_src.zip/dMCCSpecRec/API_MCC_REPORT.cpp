// API_MCC_REPORT.cpp : implementation file
//

#include "stdafx.h"
#include "dMCCSpecRec.h"
#include "API_MCC_REPORT.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


#include "MCCManger.h"

CMCCManger g_cMCCManager;
/////////////////////////////////////////////////////////////////////////////
// API_OPN


void WINAPI API_MCCR_Initialize(HWND hParentWnd, CRect r)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());
	
	g_cMCCManager.InitializeMCC(hParentWnd, r);
}

VTM_MCC* WINAPI API_MCCR_GetSharedMemory()
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());

	return g_cMCCManager.GetSharedMemory();
}

void WINAPI API_MCCR_KillThred()
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());
	
	g_cMCCManager.KillThred();
}

void WINAPI API_MCCR_FinalizeReport()
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());
	
	g_cMCCManager.Finalize();
}

void WINAPI	API_MCCR_SetLogPath(CString str)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());

	g_cMCCManager.SetLogPath(str);
}

void WINAPI	API_MCCR_SetConfigPath(CString str)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());
	
	g_cMCCManager.SetConfigPath(str);
}

CWnd* WINAPI API_MCCR_GetReportmWnd()
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());

	return g_cMCCManager.GetReportMCCWnd();
}

int WINAPI API_MCCR_AddQueue(int iFlag)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());

	return g_cMCCManager.AddMccQueue(iFlag);
}

