; CLW file contains information for the MFC ClassWizard

[General Info]
Version=1
ClassCount=3
Class1=CdMCCSpecRecApp
LastClass=CDlgnMCCReport
NewFileInclude2=#include "dMCCSpecRec.h"
ResourceCount=1
NewFileInclude1=#include "stdafx.h"
LastTemplate=generic CWnd
Class2=CDlgnMCCReport
Class3=CMCCManger
Resource1=IDD_DLG_MMC_LOG (English (U.S.))

[CLS:CdMCCSpecRecApp]
Type=0
HeaderFile=dMCCSpecRec.h
ImplementationFile=dMCCSpecRec.cpp
Filter=N
LastObject=CdMCCSpecRecApp
BaseClass=CWinApp
VirtualFilter=AC

[DLG:IDD_DLG_MMC_LOG (English (U.S.))]
Type=1
Class=CDlgnMCCReport
ControlCount=3
Control1=IDC_LIST_MCC_TLOG,SysListView32,1350631425
Control2=IDC_LIST_MCC_ILOG,SysListView32,1350631425
Control3=IDC_CTTEXTCTRL_MCC_TITLE,{5628C5DE-CCD5-11D4-A1FF-00E098856412},1342242816

[CLS:CDlgnMCCReport]
Type=0
HeaderFile=DlgnMCCReport.h
ImplementationFile=DlgnMCCReport.cpp
BaseClass=CDialog
Filter=D
VirtualFilter=dWC
LastObject=CDlgnMCCReport

[CLS:CMCCManger]
Type=0
HeaderFile=MCCManger.h
ImplementationFile=MCCManger.cpp
BaseClass=generic CWnd
Filter=W
LastObject=CMCCManger

