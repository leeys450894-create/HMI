// DlgnMCCReport.cpp : implementation file
//

#include "stdafx.h"
#include "dMCCSpecRec.h"
#include "DlgnMCCReport.h"
#include <direct.h>
#include <afxmt.h>			//CCriticalSection
#include <winver.h>
//#include "..\\Include\\AxisType.h"
#include "..\\Include\\CommonFunc.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDlgnMCCReport dialog

//CCriticalSection	g_csTime;
//CCriticalSection	g_csDir;
CCriticalSection	g_csTLog;
CCriticalSection	g_csILog;

// BOOL gf_MakeDir(CString sPath)
// {
// 	g_csDir.Lock();
// 	if (sPath[1] != ':' || sPath[2] != '\\')
// 	{
// 		g_csDir.Unlock();
// 		return FALSE;
// 	}
// 	
// 	CString sTem;
// 	int nFind = 2;
// 	while ((nFind = sPath.Find(_T("\\"),nFind+1)) >= 0)
// 	{
// 		sTem = sPath.Left(nFind);
// 		_tmkdir(sTem);
// 	}
// 
// // 	CString sTem;
// //     int nFind = 2;
// // 	while ((nFind = sPath.Find("\\",nFind+1)) >= 0)
// // 	{
// // 		sTem = sPath.Left(nFind);
// // 		_mkdir(sTem);
// // 	}
// 	
// 	g_csDir.Unlock();
// 	return TRUE;
// }

// CString gf_MakeCurTimeString()
// {
// 	g_csTime.Lock();
// 	SYSTEMTIME st;
// 	::GetLocalTime(&st);
// 	CString sTime;
// 	sTime.Format(_T("%02d%02d_%02d%02d_%02d.%03d"),st.wMonth ,st.wDay ,st.wHour ,st.wMinute ,st.wSecond, st.wMilliseconds  );
// 	g_csTime.Unlock();
// 	return sTime;
// }

CDlgnMCCReport::CDlgnMCCReport(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgnMCCReport::IDD, pParent)
	, m_strAppPath(_T(""))
	, m_nDeleteRowNum(0)
	, m_oldEvtFlag(0)
	, m_bInitDialog(false)
{
	//{{AFX_DATA_INIT(CDlgnMCCReport)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT

	m_hbrushBK = ::CreateSolidBrush(RGB_MAIN3);

	m_pWorkThread = NULL;
	m_hEvtWorkStart    = CreateEvent(NULL, FALSE, FALSE, NULL); // auto reset, initially reset
	m_hEvtWorkDone     = CreateEvent(NULL, TRUE,  TRUE,  NULL); // manual reset, initially set
	m_hEvtKillThread   = CreateEvent(NULL, FALSE, FALSE, NULL); // auto reset, initially reset
	m_hEvtThreadKilled = CreateEvent(NULL, FALSE, FALSE, NULL); // auto reset, initially reset	// jsyoon 20150224 chnage
//	m_hEvtThreadKilled = CreateEvent(NULL, TRUE, TRUE, NULL);   // auto reset, initially set

	m_strConfigPath.Empty();
	m_strLogPath.Empty();
	m_strLogFile.Empty();

	m_bInitSendToFtp = FALSE;
	m_bInitSendToFtp2 = FALSE;
	m_bMccTransferOn = FALSE;

//	m_pFtp = NULL;
	m_pCommFtpFunction = nullptr;

	m_pMCCMap = NULL;
	m_hMCCMapFile = NULL;

	CreateMemoryMap();
}


void CDlgnMCCReport::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlgnMCCReport)
	DDX_Control(pDX, IDC_LIST_MCC_TLOG, m_list_TLOG);
	DDX_Control(pDX, IDC_LIST_MCC_ILOG, m_list_ILOG);
//	DDX_Control(pDX, IDC_FPSPREAD_MCC_ILOG, m_sprdMccILog);
	//}}AFX_DATA_MAP
	DDX_Control(pDX, IDC_CHECK_T, m_chkUseSend);
}


BEGIN_MESSAGE_MAP(CDlgnMCCReport, CDialog)
	//{{AFX_MSG_MAP(CDlgnMCCReport)
	ON_WM_TIMER()
	ON_WM_CTLCOLOR()
	ON_WM_DESTROY()
	//}}AFX_MSG_MAP
	ON_BN_CLICKED(IDC_CHECK_T, &CDlgnMCCReport::OnBnClickedCheckT)
	ON_WM_SIZE()
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlgnMCCReport message handlers

BOOL CDlgnMCCReport::OnInitDialog() 
{
	CDialog::OnInitDialog();

	// sy.kim 20171020 Delete
	LV_COLUMN lvcolumn;
	lvcolumn.mask = LVCF_FMT | LVCF_SUBITEM | LVCF_TEXT | LVCF_WIDTH;
	lvcolumn.fmt = LVCFMT_LEFT;
	lvcolumn.pszText = _T("Log");
	lvcolumn.iSubItem = 0;
	lvcolumn.cx = 10000;
	m_list_TLOG.InsertColumn(0,&lvcolumn);
	m_list_ILOG.InsertColumn(0,&lvcolumn);
// 	
// 	SYSTEMTIME st;
// 	::GetLocalTime(&st);
// 	CTime ct(st);
// 	m_strLogFile.Format("%04d%02d%02d%02d%02d%02d",st.wYear,st.wMonth,st.wDay,st.wHour,st.wMinute,st.wSecond);
 	m_strEQPID.Format(_T("%s"),	m_pMCCMap->stMCCInfoEQ.szModuleID	/*m_pSystem->stTitle.m_strEquipName*/ );	// jsyoon 20161226 change
// 	m_strSendLogFile.Format("%s", m_strLogFile);	// jsyoon 20170201 add
// 
// 	m_iOldTime = st.wHour*60 + st.wMinute;
// 
	TCHAR szBuff[_MAX_PATH];
	memset(szBuff, 0, MAX_PATH);
	::GetModuleFileName(::AfxGetApp()->m_hInstance, szBuff, _MAX_PATH);
	TCHAR* pch = _tcsrchr(szBuff, _T('\\'));
	m_strAppPath = CString(szBuff, pch - szBuff + 1);

// 	TCHAR szBuff[_MAX_PATH];
// 	::GetModuleFileName(::AfxGetApp()->m_hInstance, szBuff, _MAX_PATH);	
// 	char* pch = ::strrchr(szBuff, '\\');
// 	m_strAppPath = CString(szBuff, pch - szBuff + 1);
//  	SetMccILogHeader();

 	BeginThread_WorkProc();
 	m_bInitSendToFtp = TRUE;
	
	if( m_pMCCMap->bMCCTransfer == TRUE)
	{
		m_chkUseSend.SetCheck(TRUE);
	}
	else
	{
		m_chkUseSend.SetCheck(FALSE);
	}

	SetTimer(2, 30, NULL); 

	m_bInitDialog = true;

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

bool CDlgnMCCReport::CreateMemoryMap()
{
	if (m_hMCCMapFile == NULL && m_pMCCMap == NULL)
	{	
		m_hMCCMapFile = CreateFileMapping(INVALID_HANDLE_VALUE, NULL, PAGE_READWRITE, 0, sizeof( VTM_MCC ), VTM_SHARE_MEM_STRING_MCC);

		if(!m_hMCCMapFile)
		{
			AfxMessageBox(_T("CreateFileMapping Failed (VTM_SHARE_MEM_STRING_MCC)"));
			return false;
		}

		m_pMCCMap = (VTM_MCC *) MapViewOfFile(m_hMCCMapFile, FILE_MAP_ALL_ACCESS, 0, 0, sizeof( VTM_MCC ));
		if( m_pMCCMap == NULL)
		{
			AfxMessageBox(_T("MapViewOfFile Failed (VTM_SHARE_MEM_STRING_MCC)"));
			return false;
		}
	}

	return true;
}

CString CDlgnMCCReport::GetCnfPath(int nEQType, CString sPath)
{
	CString strRet;
	strRet.Format(_T("%s%s%s"),m_strAppPath, _T("CONFIG\\MCC\\"), sPath);

// 	switch (nEQType)
// 	{
// 	case EQU_TYPE_ICE:
// 		strRet.Format(_T("%s%s%s"),m_strAppPath, _T("CONFIG\\ICE\\"), sPath);
// 		break;
// 	case EQU_TYPE_ICM:
// 		strRet.Format(_T("%s%s%s"),m_strAppPath, _T("CONFIG\\ICM\\"), sPath);
// 		break;
// 	case EQU_TYPE_ICP:
// 		strRet.Format(_T("%s%s%s"),m_strAppPath, _T("CONFIG\\ICP\\"), sPath);
// 		break;
// 	case EQU_TYPE_OCP:
// 		strRet.Format(_T("%s%s%s"),m_strAppPath, _T("CONFIG\\OCP\\"), sPath);
// 		break;
// 	default:
// 		strRet.Format(_T("%s%s%s"),m_strAppPath, _T("CONFIG\\DEFAULT\\"), sPath);
// 		break;
// 	}

	return strRet;
}

// int CDlgnMCCReport::WriteFile(CFile *pFile, CString &sPath, CString sLog)
// {
// 	if(!sLog.IsEmpty())
// 		sLog += _T("\r\n");
// 
//     BOOL bNew = FALSE;
//     CFileStatus fs;
//     if (!CFile::GetStatus(sPath, fs))  //if not exist yet
//     {
// 		gf_MakeDir(sPath);// _mkdir;
//         bNew = TRUE;
//     }
//     else if (pFile->m_hFile != CFile::hFileNull)
//     {
// 		CString s1 = fs.m_szFullName ;
// 		if ((pFile->GetFilePath() != s1))
// 		{
// 			bNew = TRUE;
// 		}
// 	}
// 	
// 	if (pFile->m_hFile != CFile::hFileNull && bNew)
// 	{
// 		pFile->Close();
// 	}
// 	
// 	CFileException* pError = NULL;
// 	if (pFile->m_hFile == CFile::hFileNull)
// 	{
// 		UINT nOpenFlags = CFile::modeReadWrite | CFile::shareDenyWrite;
//         if (bNew)
// 			nOpenFlags |= CFile::modeCreate;
// 		
// 		if (!pFile->Open(sPath , nOpenFlags, pError))
// 			return 0;
// 	}
// 	if (pFile->m_hFile != CFile::hFileNull)
// 	{
// 		if(!sLog.IsEmpty())
// 		{
// 			pFile->SeekToEnd();
// 			pFile->Write(sLog, sLog.GetLength()) ;
// 			pFile->Flush();
// 		}
// 	}
// 	return 1;
// }

int CDlgnMCCReport::WriteFile(CString sPath, CString sLog)
{
	BOOL bNew = FALSE;
	CFileStatus fs;
	CFile cfile;

	TCHAR szPath[1024];
	szPath[0] = 0x00;

	char szLog[64000];
	szLog[0] = 0x00;

	TCHAR* pCh = sPath.GetBuffer(sPath.GetLength());
	sPath.ReleaseBuffer();
	_tcscat_s(szPath, _countof(szPath), pCh);

	CString s;
	s.Format(_T("%s\n"), sLog);
	//strcpy_s(szLog, _countof(szLog), gf_StringToChar(s));
	gf_StringToChar2(s, szLog);
	int iLen = _tcslen(s);
	szLog[iLen] = 0;

	BOOL bDelete = FALSE;

	if (!CFile::GetStatus(szPath, fs))  //if not exist yet
	{
		gf_MakeDir(sPath);// _mkdir;
		bNew = TRUE;
	}
	else
	{
		bNew = FALSE;

		// jsyoon 20200625 add
		CTime ct = CTime::GetCurrentTime();
		CTimeSpan spanDay1 = fs.m_mtime.GetTime();		// ���� ������ ���� �ð�
		CTimeSpan spanDay2 = ct.GetTime();				// ���� �ð�
		LONGLONG lDays = spanDay2.GetTotalHours() - spanDay1.GetTotalHours();

		if (lDays > 27)
		{
			bDelete = TRUE;
			bNew = TRUE;
		}
		///
	}

	if (bDelete == TRUE)
	{
		DeleteFile(sPath);	// ����
	}

	CFileException* pError = NULL;
	UINT nOpenFlags = CFile::modeReadWrite | CFile::shareDenyWrite;
	if (bNew)
		nOpenFlags |= CFile::modeCreate;

	if (!cfile.Open(szPath, nOpenFlags, pError))
		return 0;

	if (cfile.m_hFile != CFile::hFileNull)
	{
		try
		{
			cfile.SeekToEnd();
			cfile.Write(szLog, iLen);
			cfile.Flush();

			cfile.Close();
		}
		catch (...)
		{
			return VTM_RV_FAILED;
		}
	}

	return VTM_RV_SUCCESSED;
}

int CDlgnMCCReport::TLOG(CString s)
{
	s.FreeExtra();
	if (m_strLogPath.IsEmpty()) return 0;

	g_csTLog.Lock();
	
	CString strPath, strLog;
	m_strTLogFile.Format(_T("T-%s-%s.csv"), m_strEQPID,m_strLogFile);	// "T" LOG T-EQPID-YYYYMMDDhhmmss.csv 
//	strPath.Format("%s\\%s",m_strLogPath,m_strTLogFile);
	strPath.Format(_T("%s\\T\\%s"),m_strLogPath,m_strTLogFile);		// jsyoon 20161226 change
	if( s.IsEmpty())
		strLog.Format(_T(""));		// jsyoon 20161229 add
	else
		strLog.Format(_T("%s"),s);
	//		strLog.Format("%s,%s",gf_MakeCurTimeString(),s);
		
//	int nR = WriteFile(&m_fileTLog, strPath, strLog);
	int nR = WriteFile(strPath, strLog);

	if( !s.IsEmpty())
	{
		if (nR > 0)
		{
			AddString(strLog);
		}
		else
		{
			strLog += _T("-->File Save Failed");
			AddString(strLog);
		}
	}

	g_csTLog.Unlock();
	
	return nR;
}

int CDlgnMCCReport::ILOG(CString s)
{
	s.FreeExtra();
	if (m_strLogPath.IsEmpty()) return 0;

	g_csILog.Lock();
	
	CString strPath, strLog;
	m_strILogFile.Format(_T("I-%s-%s.csv"), m_strEQPID,m_strLogFile);	// "T" LOG T-EQPID-YYYYMMDDhhmmss.csv 
//	strPath.Format("%s\\%s",m_strLogPath,m_strTLogFile);
	strPath.Format(_T("%s\\I\\%s"),m_strLogPath,m_strILogFile);		// jsyoon 20161226 change
	if( s.IsEmpty())
		strLog.Format(_T(""));		// jsyoon 20161229 add
	else
		strLog.Format(_T("%s"),s);
	
//	int nR = WriteFile(&m_fileILog, strPath, strLog);
	int nR = WriteFile(strPath, strLog);

	if( !s.IsEmpty())
	{
		if (nR > 0)
		{
			AddString(strLog, 1);
		}
		else
		{
			strLog += _T("-->File Save Failed");
			AddString(strLog, 1);
		}
	}

	g_csILog.Unlock();
	
	return nR;
}

int CDlgnMCCReport::indexLOG()
{
	if (m_strLogPath.IsEmpty()) return 0;
	
	CString strPath = _T(""), strLog = _T("");
	m_strindexFile.Format(_T("index-%s-%s.csv"),m_strEQPID,m_strLogFile);		// "Index" LOG index-EQPID-YYYYMMDDhhmmss.csv 
//	strPath.Format("%s\\%s",m_strLogPath,m_strindexFile);
	strPath.Format(_T("%s\\INDEX\\%s"),m_strLogPath,m_strindexFile);	// jsyoon 20161226 change
	
//	int nR = WriteFile(&m_fileindexLog,strPath,strLog);
	int nR = WriteFile(strPath, strLog);
	
	return nR;
}

void CDlgnMCCReport::AddString(CString &sLog, int iList)
{
	switch (iList)
	{
	case 0:		// TLOG
		{
			if (m_list_TLOG.m_hWnd == NULL) return;
			int i=m_list_TLOG.GetItemCount();
			m_list_TLOG.InsertItem(i,_T(""));
			m_list_TLOG.SetItemText(i, 0, sLog);
			
			CString str = m_list_TLOG.GetItemText(i,0);	
			if (m_list_TLOG.GetScrollLimit(SB_VERT) == m_list_TLOG.GetScrollPos(SB_VERT)+1)
			{
				if (i>0)
					m_list_TLOG.EnsureVisible(i,FALSE);
			}
			
			if (i > 1000)
				m_list_TLOG.DeleteItem(0);
		}
		break;
	case 1:		// ILOG
		{
			if (m_list_ILOG.m_hWnd == NULL) return;
			int i=m_list_ILOG.GetItemCount();
			m_list_ILOG.InsertItem(i,_T(""));
			m_list_ILOG.SetItemText(i, 0, sLog);
			
			CString str = m_list_ILOG.GetItemText(i,0);	
			if (m_list_ILOG.GetScrollLimit(SB_VERT) == m_list_ILOG.GetScrollPos(SB_VERT)+1)
			{
				if (i>0)
					m_list_ILOG.EnsureVisible(i,FALSE);
			}
			
			if (i > 1000)
				m_list_ILOG.DeleteItem(0);
		}
		break;
	}
}

void CDlgnMCCReport::OnTimer(UINT nIDEvent) 
{	
	if(nIDEvent == 1)	// Log File name
	{
		SYSTEMTIME st;
		::GetLocalTime(&st);
		CTime ct(st);

		UINT iCurTime = 0;
		iCurTime = st.wHour*60 + st.wMinute;

		// jsyoon 20150224 change
		if( st.wSecond == 0)							// 1m
		{
			if( m_bInitSendToFtp)
			{
				SetTimer(3, 1000, NULL);
				SetTimer(4, 1000, NULL);

				m_iOldTime = iCurTime;
				m_strNewLogFile.Format(_T("%04d%02d%02d%02d%02d%02d"),st.wYear,st.wMonth,st.wDay,st.wHour,st.wMinute,0/*st.wSecond*/);
				m_bInitSendToFtp = FALSE;

				m_strLogFile.Format(_T("%s"), m_strNewLogFile);
				indexLOG();
				TLOG(_T(""));
				//WriteMCCInfo(0);
				SetMccILogHeader();
				UpdateMCCILOG();
			}
			else
			{
				if( m_bInitSendToFtp2 == TRUE)
				{
					if( (UINT)labs(iCurTime - m_iOldTime) >= m_pMCCMap->uMCCUploadTime)	// jsyoon 20150205
					{	
					//	KillTimer(3);
					//	KillTimer(4);

					//	UpdateMCCILOG();

						m_strSendLogFile.Format(_T("%s"), m_strLogFile);

						m_iOldTime = iCurTime;
						SetSendToFtp();

						m_strNewLogFile.Format(_T("%04d%02d%02d%02d%02d%02d"),st.wYear,st.wMonth,st.wDay,st.wHour,st.wMinute,0/*st.wSecond*/);

						m_strLogFile.Format(_T("%s"), m_strNewLogFile);
						indexLOG();
						TLOG(_T(""));
					//	WriteMCCInfo(0);
						SetMccILogHeader();

					//	SetTimer(3, 1000, NULL);
					//	SetTimer(4, 1000, NULL);
					}
				}
				else
				{
					if( st.wSecond == 0 && (st.wMinute % 10) == 0)
					{
						m_strSendLogFile.Format(_T("%s"), m_strLogFile);

						m_iOldTime = iCurTime;
						SetSendToFtp();

						m_strNewLogFile.Format(_T("%04d%02d%02d%02d%02d%02d"),st.wYear,st.wMonth,st.wDay,st.wHour,st.wMinute,0/*st.wSecond*/);
						m_bInitSendToFtp2 = TRUE;

						m_strLogFile.Format(_T("%s"), m_strNewLogFile);
						indexLOG();
						TLOG(_T(""));
						SetMccILogHeader();
					}
				}	
			}
		}
	}

	if(nIDEvent == 2)
	{
// 		int iMaxRow = 0;
// 		if( m_nDeleteRowNum != 0)
// 		{
// 			m_sprdMccILog.DeleteRows(1, m_nDeleteRowNum);					//���õ� Row�� ���� �����
// 			iMaxRow = m_sprdMccILog.GetMaxRows();
// 			m_sprdMccILog.SetMaxRows(iMaxRow-m_nDeleteRowNum);
// 			m_sprdMccILog.Refresh();
// 			m_nDeleteRowNum = 0;
// 		}
// 
// 		iMaxRow = m_sprdMccILog.GetMaxRows();
// 		UpdateMCCInfo(iMaxRow);

		
		SYSTEMTIME st;
		::GetLocalTime(&st);
		CTime ct(st);

		if( st.wMilliseconds > 900)							// 1m
		{
			KillTimer(2);
			SetTimer(1, 100, NULL);

// 			WriteMCCInfo(0);
// 			SetTimer(4, 1000, NULL);
		}
	}

	if(nIDEvent == 3)
	{
		UpdateMCCTLog();
	}

	if(nIDEvent == 4)
	{
		UpdateMCCILOG();	// jsyoon 20170124 change
	}

	
	CDialog::OnTimer(nIDEvent);
}

// eVent
void CDlgnMCCReport::WriteMCCEvent(int iEvent, BOOL bStart)
{
	CString strLog;
	strLog.Format(_T(""));
	bStart;
	iEvent;
	TLOG(strLog);
}

// information
void CDlgnMCCReport::WriteMCCInfo(int iRow)
{
	m_list_ILOG.DeleteAllItems();  

	CString strLog, strValue, strData;
	strLog.Empty();

// 	m_sprdMccILog.SetRow(iRow);
// 	int nMaxCol = 0;
// 	nMaxCol = m_sprdMccILog.GetMaxCols();
// //	for (int iCol = 1; iCol<MCC_ILOG_COL_END; iCol++)
// 	for (int iCol = 1; iCol<=nMaxCol; iCol++)
// 	{
// 		m_sprdMccILog.SetCol(iCol);
// 		strValue = m_sprdMccILog.GetValue();
// 		strValue.TrimLeft();
// 		strValue.TrimRight();
// 		if( iCol == nMaxCol)
// 			strData.Format(_T("%s"), strValue);
// 		else
// 			strData.Format(_T("%s,"), strValue);
// 
// 		strLog += strData;
// 	}

	ILOG(strLog);
}

// Action
void CDlgnMCCReport::WriteMCCAction(CString strTime, int iAction, BOOL bStart, int nStep/* = 0*/, int nFromto/* = 0*/)
{
	// Event Time, Module ID, Log Type, StepID, GlassID, LotID, Eqp PPID, Action Name, Form Pos, to Pos, START or END
	CString strLog;
	if( nStep == 0)
	{
		strLog.Format(_T("%s,%s,A,%s,%s,%s,%s=%s,%s=%s=%s"), 
			strTime,
			m_pMCCMap->stMCCInfoEQ.szModuleID, 
			m_pMCCMap->stMCCInfoEQ.szStepID, 
			m_pMCCMap->stMCCInfoEQ.szGlassID, 
			m_pMCCMap->stMCCInfoEQ.szLotID, 
			m_pMCCMap->stMCCInfoEQ.szRecipeID, 
			m_pMCCMap->stMCCInfoEQ.szRecipeID, 
			GetActiontoStr(iAction), 
			GetFromto(nFromto),
			(bStart)? _T("START"):_T("END"));
	}
	else
	{
		strLog.Format(_T("%s,%s,A,%s,%s,%s,%s=%s,%s_%d=%s=%s"), 
			strTime,
			m_pMCCMap->stMCCInfoEQ.szModuleID, 
			m_pMCCMap->stMCCInfoEQ.szStepID, 
			m_pMCCMap->stMCCInfoEQ.szGlassID, 
 			m_pMCCMap->stMCCInfoEQ.szLotID, 
			m_pMCCMap->stMCCInfoEQ.szRecipeID, 
			m_pMCCMap->stMCCInfoEQ.szRecipeID, 
			GetActiontoStr(iAction),
			nStep,
			GetFromto(nFromto),
			(bStart)? _T("START"):_T("END"));
	}
// 	strLog.Format("%s,%s,A,%s,%s,%s,%s=%s,%s=%s=%s=%s", 
// 		strTime,
// 		m_pSystem->m_strEquipName, 
// 		m_pSystem->stLotInfo.m_szStepID, 
// 		m_pSystem->stLotInfo.m_szGlassID, 
// 		m_pSystem->stLotInfo.m_szLotID, 
// 		m_pSystem->stLotInfo.m_szRecipeID, 
// 		m_pSystem->stLotInfo.m_szRecipeID, 
// 		GetActiontoStr(iAction), 
// 		m_pSystem->m_strEquipName,
// 		m_pSystem->m_strEquipName,
// 		(bStart)? "START":"END");
	
	TLOG(strLog);
}

// Signal
void CDlgnMCCReport::WriteMCCSignal(CString strTime, int iSignal, BOOL bStart, int nFromto/* = 0*/)
{
	// Event Time, Module ID, Log Type, StepID, GlassID, LotID, Eqp PPID, Action Name, Form Pos, to Pos, START or END
	CString strLog;
	strLog.Format(_T("%s,%s,S,%s,%s,%s,%s=%s,%s=%s=%s"), 
		strTime,
		m_pMCCMap->stMCCInfoEQ.szModuleID, 
		m_pMCCMap->stMCCInfoEQ.szStepID, 
		m_pMCCMap->stMCCInfoEQ.szGlassID, 
		m_pMCCMap->stMCCInfoEQ.szLotID, 
		m_pMCCMap->stMCCInfoEQ.szRecipeID, 
		m_pMCCMap->stMCCInfoEQ.szRecipeID, 
		GetSignaltoStr(iSignal), 
		GetFromto(nFromto),
		(bStart)? _T("START"):_T("END"));

	TLOG(strLog);
}

// Error
void CDlgnMCCReport::WriteMCCError(CString strTime,int iError, BOOL bSet)
{
	CString strLog;
	strLog.Format(_T("%s,%s,E,%s,%s,%s,%s,%s=%s"), 
		strTime,

		m_pMCCMap->stMCCInfoEQ.szModuleID, 
		m_pMCCMap->stMCCInfoEQ.szStepID, 
		m_pMCCMap->stMCCInfoEQ.szGlassID, 
		m_pMCCMap->stMCCInfoEQ.szLotID, 
		m_pMCCMap->stMCCInfoEQ.szRecipeID, 
		(bSet)? _T("SET"):_T("RESET"),
 		GetErrortoStr(iError));

	TLOG(strLog);
}

// Warning
void CDlgnMCCReport::WriteMCCWarring(CString strTime,int iError, BOOL bSet)
{
	CString strLog;
	strLog.Format(_T("%s,%s,W,%s,%s,%s,%s,%s=%s"),
		strTime,
		m_pMCCMap->stMCCInfoEQ.szModuleID, 
		m_pMCCMap->stMCCInfoEQ.szStepID, 
		m_pMCCMap->stMCCInfoEQ.szGlassID, 
		m_pMCCMap->stMCCInfoEQ.szLotID, 
		m_pMCCMap->stMCCInfoEQ.szRecipeID, 
		(bSet)? _T("SET"):_T("RESET"),
		GetErrortoStr(iError));

	TLOG(strLog);
}

CString CDlgnMCCReport:: GetFromto(int iAction)
{
	CString str;
	str.Empty();


	switch (iAction)
	{
	case 0:		// EQ to EQ
		str.Format(_T("%s=%s"), m_pMCCMap->stMCCInfoEQ.szEquipToName,m_pMCCMap->stMCCInfoEQ.szEquipToName);
		break;
	case 1:		// TM to EQ
		str.Format(_T("%s=%s"), m_pMCCMap->stMCCInfoEQ.szEquipFromName,m_pMCCMap->stMCCInfoEQ.szEquipToName);
		break;
	case 2:		// EQ to TM
		str.Format(_T("%s=%s"), m_pMCCMap->stMCCInfoEQ.szEquipToName,m_pMCCMap->stMCCInfoEQ.szEquipFromName);
		break;
	default:	
		str.Format(_T("%s=%s"), m_pMCCMap->stMCCInfoEQ.szEquipToName,m_pMCCMap->stMCCInfoEQ.szEquipToName);
		break;
	}

	return str;
}

CString CDlgnMCCReport::GetActiontoStr(int iAction)
{
	CString str;
	str.Empty();

	CFileFind finder;

	CString strMCCFile;
	strMCCFile = GetCnfPath(m_pMCCMap->nEQType, MCC_ACTION_FILE);		// jsyoon 20170529 change
	if (finder.FindFile(strMCCFile) == FALSE)
	{
		str.Format(_T("Can not fined '%s'"), strMCCFile);
		AfxMessageBox(str);
		return _T("");
	}

	CString strLine, strValue, strName;
	CStringArray strArray;
	CString strTemp;
	int lenTemp = 0, iCol = 0;

//	CFile fileMCC(strMCCFile, CFile::shareDenyNone );
//	CArchive ar(&fileMCC, CArchive::load);
	CStdioFile File(strMCCFile, CFile::modeRead);

	do 
	{
		if (File.ReadString(strLine))
		{
			int iStart = 0;
			int iEnd   = 0;
			bool bToggle = TRUE;

			strArray.RemoveAll();

			lenTemp = strLine.GetLength();
			for(int i = 0 ; i < lenTemp; i++)
			{		
				if(bToggle)
				{
					iStart = i;
					bToggle = FALSE;
				}

				if(strLine.GetAt(i) == ',')
				{
					bToggle = TRUE;
					iEnd = i;
					iEnd -= iStart;

					strTemp = strLine.Mid(iStart, iEnd);
					strArray.Add(strTemp);
				}
				else if( i == lenTemp-1 )
				{
					iEnd = i;
					iEnd -= iStart;

					strTemp = strLine.Mid(iStart, iEnd+1);
					strArray.Add(strTemp);
				}
			}

			if( strArray.GetSize() > 2 )
			{
				strValue = strArray.GetAt(0);
				strValue.TrimRight();

				strName = strArray.GetAt(2);
				strName.TrimRight();
			}

			if( strValue.CompareNoCase(_T("NO")) == 0)
				continue;

			if (iAction == _ttoi(strValue))
			{
				str.Format(_T("%s"), strName);
				break;
			}
		}
		else				// End file
		{
			break;
		}
	} while (TRUE);

	File.Close();
// 	ar.Close();
// 	fileMCC.Close();	

	return str;
}

CString CDlgnMCCReport::GetSignaltoStr(int iSignal)
{
	CString str;
	str.Empty();

	CFileFind finder;

	CString strMCCFile;
	strMCCFile = GetCnfPath(m_pMCCMap->nEQType, MCC_SIGNAL_FILE);		// jsyoon 20170529 change
	if (finder.FindFile(strMCCFile) == FALSE)
	{
		str.Format(_T("Can not fined '%s'"), strMCCFile);
		AfxMessageBox(str);
		return _T("");
	}

	CString strLine, strValue, strName;
	CStringArray strArray;
	CString strTemp;
	int lenTemp = 0, iCol = 0;

	//CFile fileMCC(strMCCFile, CFile::shareDenyNone );
	//CArchive ar(&fileMCC, CArchive::load);

	CStdioFile File(strMCCFile, CFile::modeRead);
	do 
	{
//		if (ar.ReadString(strLine))
		if (File.ReadString(strLine))
		{
			int iStart = 0;
			int iEnd   = 0;
			bool bToggle = TRUE;

			strArray.RemoveAll();

			lenTemp = strLine.GetLength();
			for(int i = 0 ; i < lenTemp; i++)
			{		
				if(bToggle)
				{
					iStart = i;
					bToggle = FALSE;
				}

				if(strLine.GetAt(i) == ',')
				{
					bToggle = TRUE;
					iEnd = i;
					iEnd -= iStart;

					strTemp = strLine.Mid(iStart, iEnd);
					strArray.Add(strTemp);
				}
				else if( i == lenTemp-1 )
				{
					iEnd = i;
					iEnd -= iStart;

					strTemp = strLine.Mid(iStart, iEnd+1);
					strArray.Add(strTemp);
				}
			}

			if( strArray.GetSize() > 2 )
			{
				strValue = strArray.GetAt(0);
				strValue.TrimRight();

				strName = strArray.GetAt(2);
				strName.TrimRight();
			}

			if( strValue.CompareNoCase(_T("NO")) == 0)
				continue;

			if (iSignal == _ttoi(strValue))
			{
				str.Format(_T("%s"), strName);
				break;
			}
		}
		else				// End file
		{
			break;
		}
	} while (TRUE);

// 	ar.Close();
// 	fileMCC.Close();	
	File.Close();

	return str;
}

CString CDlgnMCCReport::GetErrortoStr(int iError)
{
	CString str;
	str.Empty();

	CFileFind finder;

	CString strMCCFile;
//	strMCCFile.Format("%s%s%s",m_strAppPath, STR_DIR_CONFIG,  MCC_ERROR_FILE);
	strMCCFile = GetCnfPath(m_pMCCMap->nEQType, MCC_ERROR_FILE);		// jsyoon 20170529 change
	if (finder.FindFile(strMCCFile) == FALSE)
	{
		str.Format(_T("Can not fined '%s'"), strMCCFile);
		AfxMessageBox(str);
		return _T("");
	}

	CString strLine, strValue, strType, strName;
	CStringArray strArray;
	CString strTemp;
	int lenTemp = 0, iCol = 0;

// 	CFile fileMCC(strMCCFile, CFile::shareDenyNone );
// 	CArchive ar(&fileMCC, CArchive::load);
	CStdioFile File(strMCCFile, CFile::modeRead);
	do 
	{
		if (File.ReadString(strLine))
		{
			int iStart = 0;
			int iEnd   = 0;
			bool bToggle = TRUE;

			strArray.RemoveAll();

			lenTemp = strLine.GetLength();
			for(int i = 0 ; i < lenTemp; i++)
			{		
				if(bToggle)
				{
					iStart = i;
					bToggle = FALSE;
				}

				if(strLine.GetAt(i) == ',')
				{
					bToggle = TRUE;
					iEnd = i;
					iEnd -= iStart;

					strTemp = strLine.Mid(iStart, iEnd);
					strArray.Add(strTemp);
				}
				else if( i == lenTemp-1 )
				{
					iEnd = i;
					iEnd -= iStart;

					strTemp = strLine.Mid(iStart, iEnd+1);
					strArray.Add(strTemp);
				}
			}

			if( strArray.GetSize() > 2 )
			{
				strValue = strArray.GetAt(0);
				strValue.TrimRight();

				strType = strArray.GetAt(1);
				strType.TrimRight();

				strName = strArray.GetAt(2);
				strName.TrimRight();
			}

			if( strValue.CompareNoCase(_T("NO")) == 0)
				continue;

			if (iError == _ttoi(strValue))
			{
				str.Format(_T("%s%s=%s"), strType,strValue,strName);
				break;
			}
		}
		else				// End file
		{
			break;
		}
	} while (TRUE);

// 	ar.Close();
// 	fileMCC.Close();	
	File.Close();

	return str;
}


UINT CDlgnMCCReport::WorkThreadProbeProc(LPVOID pParam)
{
	CDlgnMCCReport* pProc = (CDlgnMCCReport*)pParam;
	
	BOOL bWorkDone = FALSE;
	while (TRUE)
	{
		// m_hEvtWorkStart Event �ñ׳��� Set �ɶ� ���� ���� �� ��ٸ���.
		// �������� Job�� ������ ���⼭ ���
		if (WaitForSingleObject(pProc->m_hEvtWorkStart, INFINITE)
			!= WAIT_OBJECT_0)
		{
			SetEvent(pProc->m_hEvtThreadKilled);
			break;
		}
		
		// m_hEvtKillThread Event �ñ׳��� Set �Ǹ� Loop�� ���� ������
		if (WaitForSingleObject(pProc->m_hEvtKillThread, 0)
			== WAIT_OBJECT_0)
		{
			SetEvent(pProc->m_hEvtThreadKilled);
			break; // Terminate this thread by exiting the proc.
		}
		
		//pProc->m_hEvtWorkDone�� ���� ���� �۾��� �� ���� ����(not Done)���·� �����Ѵ�
		//����, �۾��� �����ϱ����� --> �۾����̶�� �ǹ̷� ��
		ResetEvent(pProc->m_hEvtWorkDone);
		
		//////////////////////////////////
		bWorkDone = pProc->GoToWork(pParam);	//���� �۾��� �����ϴ� �Լ�
		//////////////////////////////////

		SetEvent(pProc->m_hEvtWorkDone);
		
		if(pProc->m_nProcessJobNo == WORK_MCC_KILL_JOB)		
		{
			SetEvent(pProc->m_hEvtThreadKilled);		
			break;;
		}
	}
	
	return 0;
}

void CDlgnMCCReport::BeginThread_WorkProc()
{
	m_nProcessJobNo = 0;		// jsyoon 20150224 add

	if (m_pWorkThread == NULL)
	{
		m_pWorkThread =	AfxBeginThread(WorkThreadProbeProc, this);
	}
	
	SetEvent  (m_hEvtWorkDone);
	ResetEvent(m_hEvtKillThread);		//Reset �ǹ̴� �����带 ���̶�� ��ȣ�� ���� ����
	ResetEvent(m_hEvtThreadKilled);		//Reset �ǹ̴� �����尡 ��� ����
}

BOOL CDlgnMCCReport::GoToWork(LPVOID pParam)
{
	pParam;

	BOOL bRet = TRUE;
	int nCmd = m_nProcessJobNo;
	
	switch ( nCmd )
	{
	case WORK_MCC_SEND_LOGFILE:
		SendToFtpServer();
		break;
	case WORK_MCC_KILL_JOB:
		break;
	default : 
		break;
	}
	
	return bRet;
}

BOOL CDlgnMCCReport::SendToFtpServer()
{
	if( m_pMCCMap != nullptr)
	{
		if(m_pMCCMap->bMCCTransfer != TRUE) 
		{
			return TRUE;
		}
	}

//	gLog(m_pSystem->hLog, "SendPPIDFileToFTP() Start");
	
	TCHAR	szConfigFile[MAX_PATH];
	CString sPath, strValue;
	sPath.Format(_T("%s%s"), m_strConfigPath, dfDEFAULT_CONFIG_MCC_FILE_PATH);
//	strcpy(szConfigFile,sPath);
	_tcscpy_s(szConfigFile, _countof(szConfigFile), sPath);
	

	FtpInfo	Info;
	Info.bPassive = TRUE;

	TCHAR szValue[256];
	ZeroMemory(&szValue, sizeof(szValue));
	char szIP[256];
	szIP[0] = 0x00;
	GetPrivateProfileString(_T("FTP"),_T("IP"),_T("192.168.100.167"), szValue, MAX_PATH,szConfigFile);
	strValue.Format(_T("%s"), szValue);
	strcpy_s(szIP, _countof(szIP), gf_StringToChar(strValue));
	Info.host = strValue;
	
	char szPort[256];
	szPort[0] = 0x00;
	GetPrivateProfileString(_T("FTP"),_T("PORT"),_T("21"), szValue, MAX_PATH,szConfigFile);
	strValue.Format(_T("%s"), szValue);
	strcpy_s(szPort, _countof(szPort), gf_StringToChar(strValue));
	Info.port = _ttoi(strValue);
	
	char szID[256];
	szID[0] = 0x00;
	GetPrivateProfileString(_T("FTP"),_T("ID"),_T("administrator"), szValue, MAX_PATH,szConfigFile);
	strValue.Format(_T("%s"), szValue);
	strcpy_s(szID, _countof(szID), gf_StringToChar(strValue));
	Info.username = strValue;
	
	char szPW[256];
	szPW[0] = 0x00;
	GetPrivateProfileString(_T("FTP"),_T("PASSWORD"),_T("1234"), szValue, MAX_PATH,szConfigFile);
	strValue.Format(_T("%s"), szValue);
	strcpy_s(szPW, _countof(szPW), gf_StringToChar(strValue));
	Info.password = strValue;

	CString strTLogFile, strILogFile, strindexFile;
	strTLogFile.Format(_T("T-%s-%s.csv"),		 m_strEQPID,m_strSendLogFile);	// "T" LOG T-EQPID-YYYYMMDDhhmmss.csv
	strILogFile.Format(_T("I-%s-%s.csv"),		 m_strEQPID,m_strSendLogFile);	// "I" LOG T-EQPID-YYYYMMDDhhmmss.csv
	strindexFile.Format(_T("index-%s-%s.csv"),   m_strEQPID,m_strSendLogFile);	// "index" LOG T-EQPID-YYYYMMDDhhmmss.csv

// 	strTLogFile.Format("T-%s-%s.csv",		 m_strEQPID,m_strLogFile);	// "T" LOG T-EQPID-YYYYMMDDhhmmss.csv
// 	strILogFile.Format("I-%s-%s.csv",		 m_strEQPID,m_strLogFile);	// "I" LOG T-EQPID-YYYYMMDDhhmmss.csv
// 	strindexFile.Format("index-%s-%s.csv",   m_strEQPID,m_strLogFile);	// "index" LOG T-EQPID-YYYYMMDDhhmmss.csv

// 	m_strLogFile = m_strNewLogFile;
// 	indexLOG();
// 	TLOG(_T(""));
// //	ILOG(_T(""));	// jsyoon 20170201 remove
// 	WriteMCCInfo(0);
// 	int iMaxRow = 0;
// 	iMaxRow = m_sprdMccILog.GetMaxRows();
// 	for (int iRow=0; iRow <= iMaxRow; iRow++)
// 	{
// 		WriteMCCInfo(iRow);
// 	}
// 	m_nDeleteRowNum = iMaxRow;


	if( m_pCommFtpFunction == nullptr)
		m_pCommFtpFunction = new CCommFtpFunction;

	if (m_pCommFtpFunction->Connect(Info) == FALSE)
	{
		if( m_pCommFtpFunction != nullptr)
		{
			delete m_pCommFtpFunction;
			m_pCommFtpFunction = nullptr;
		}
		
		return FALSE;
	}

	BOOL bRet = TRUE;
	CStringArray strSendFile, strRemoteFile;
	strSendFile.RemoveAll();
	strRemoteFile.RemoveAll();

	if (!m_strLogPath.IsEmpty())
	{
		CString strTmep,  strRemotePath;

		// T
		strTmep.Format(_T("%s\\T\\%s"), m_strLogPath,strTLogFile);
		strSendFile.Add(strTmep);

		strRemotePath.Format(_T("MCC\\T\\%s"), strTLogFile);
		strRemoteFile.Add(strRemotePath);

		// I
		strTmep.Format(_T("%s\\I\\%s"), m_strLogPath, strILogFile);
		strSendFile.Add(strTmep);

		strRemotePath.Format(_T("MCC\\I\\%s"), strILogFile);
		strRemoteFile.Add(strRemotePath);
		
		// Index
		strTmep.Format(_T("%s\\INDEX\\%s"), m_strLogPath, strindexFile);
		strSendFile.Add(strTmep);

		strRemotePath.Format(_T("MCC\\%s"), strindexFile);
		strRemoteFile.Add(strRemotePath);

		bool bSendResult = true;
		for (size_t i = 0; i < strSendFile.GetSize(); ++i)
		{
			CString strLocal_FilePath = strSendFile.GetAt(i);
			CString strRemoteFilePath = strRemoteFile.GetAt(i);
			strLocal_FilePath.Replace(_T("\r"), _T(""));
			strLocal_FilePath.Replace(_T("\n"), _T(""));
			strRemoteFilePath.Replace(_T("\r"), _T(""));
			strRemoteFilePath.Replace(_T("\n"), _T(""));

			bool bUploadFileToFTP = false;
			for (long n = 0; n < 3; ++n)
			{
				if (m_pCommFtpFunction->Upload(strLocal_FilePath, strRemoteFilePath) == TRUE)
				{
					bUploadFileToFTP = true;
					break;
				}
			}

			bSendResult &= bUploadFileToFTP;
		}

		if( bSendResult != true)
		{
			bRet = FALSE;
		}
	}

	if( m_pCommFtpFunction != nullptr) 
	{
		delete m_pCommFtpFunction;
		m_pCommFtpFunction = nullptr;
	}

	
	/*
	if( m_pFtp == NULL)
		m_pFtp = new CFTP_Op;

	if(m_pFtp->ConnectToFTP(szIP, szID, szPW, atoi(szPort), TRUE))
	{
		if( m_pFtp != NULL)
		{
			m_pFtp->CloseFTPConnection();
			delete m_pFtp;	
			m_pFtp = NULL;
		}
		return FALSE;
	}
		
	if (!m_strLogPath.IsEmpty())
	{
		char szTemp[6400];
		szTemp[0] = 0x00;
		char szTempFile[1024];
		szTempFile[0] = 0x00;
			
		CString strTmep,  strRemotePath;
		strRemotePath.Format(_T("MCC\\T\\%s"), strTLogFile);
//			strcpy(m_szTempFile, strRemotePath);
//			_tcscpy_s(m_szTempFile, _countof(m_szTempFile), strRemotePath);
		strcpy_s(szTempFile, _countof(szTempFile), gf_StringToChar(strRemotePath));

//			strTmep.Format("%s\\%s",m_strLogPath,strTLogFile);
		strTmep.Format(_T("%s\\T\\%s"), m_strLogPath,strTLogFile);		// jsyoon 20161226 change
	//	_tcscpy_s(m_szTemp, _countof(m_szTemp), strTmep);
		strcpy_s(szTemp, _countof(szTemp), gf_StringToChar(strTmep));

		if( m_pFtp->SendFileToFTP(szTemp,szTempFile) == 0) 
		{
			strRemotePath.Format(_T("MCC\\I\\%s"), strILogFile);
		//	_tcscpy_s(m_szTempFile, _countof(m_szTempFile), strRemotePath);
			strcpy_s(szTempFile, _countof(szTempFile), gf_StringToChar(strRemotePath));
					
//				strTmep.Format("%s\\%s", m_strLogPath, strILogFile);
			strTmep.Format(_T("%s\\I\\%s"), m_strLogPath, strILogFile);		// jsyoon 20161226 change
		//	_tcscpy_s(m_szTemp, _countof(m_szTemp), strTmep);
			strcpy_s(szTemp, _countof(szTemp), gf_StringToChar(strTmep));

			if( m_pFtp->SendFileToFTP(szTemp,szTempFile) == 0)
			{
				strRemotePath.Format(_T("MCC\\%s"), strindexFile);
			//	_tcscpy_s(m_szTempFile, _countof(m_szTempFile), strRemotePath);
				strcpy_s(szTempFile, _countof(szTempFile), gf_StringToChar(strRemotePath));

//					strTmep.Format("%s\\%s", m_strLogPath, strindexFile);
				strTmep.Format(_T("%s\\INDEX\\%s"), m_strLogPath, strindexFile);	// jsyoon 20161226 change
			//	_tcscpy_s(m_szTemp, _countof(m_szTemp), strTmep);
				strcpy_s(szTemp, _countof(szTemp), gf_StringToChar(strTmep));
				m_pFtp->SendFileToFTP(szTemp,szTempFile);
			}
		}
	}

	if( m_pFtp != NULL)
	{
		m_pFtp->CloseFTPConnection();
		delete m_pFtp;	
		m_pFtp = NULL;
	}
	*/

	return bRet;
}

void CDlgnMCCReport::SetSendToFtp()
{
	if (WaitForSingleObject(m_hEvtWorkDone, 0)	== WAIT_OBJECT_0)	// jsyoon 20160211 add
	{
		m_nProcessJobNo	= WORK_MCC_SEND_LOGFILE;
		SetEvent(m_hEvtWorkStart);
	}
}

HBRUSH CDlgnMCCReport::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor) 
{
	HBRUSH hbr = CDialog::OnCtlColor(pDC, pWnd, nCtlColor);
	
	if (pWnd == this)	return m_hbrushBK;

	return hbr;
}

void CDlgnMCCReport::OnDestroy() 
{
	CDialog::OnDestroy();

	CloseHandle(m_hEvtWorkStart);
	CloseHandle(m_hEvtWorkDone);
	CloseHandle(m_hEvtKillThread);
	CloseHandle(m_hEvtThreadKilled);

	::DeleteObject(m_hbrushBK);
}

void CDlgnMCCReport::KillThred()
{
	SetEvent(m_hEvtKillThread);
	m_nProcessJobNo	= WORK_MCC_KILL_JOB;
	SetEvent(m_hEvtWorkStart);

	KillTimer(1);
	KillTimer(2);
	KillTimer(3);
	KillTimer(4);
}

void CDlgnMCCReport::SetLogPath(CString str)
{
	m_strLogPath = str;

// 	indexLOG();
// 	TLOG(_T(""));
// 	ILOG(_T(""));
}

void CDlgnMCCReport::SetConfigPath(CString str)
{
	m_strConfigPath = str;
}

BOOL CDlgnMCCReport::WaitTerminateWorkerThread()
{
	{	
		if (WaitForSingleObject(m_hEvtThreadKilled, 5000)
			== WAIT_OBJECT_0)
		{
			m_pWorkThread = NULL;
		}
	}
	
	if( m_pWorkThread == NULL )
		TRACE("MCCReport NULL @@@@@@@@@@@\n");
	
	return TRUE;
}


int CDlgnMCCReport::SetMccILogHeader(void)
{
// 	m_sprdMccILog.SetMaxRows(0);
// 	m_sprdMccILog.SetMaxCols(500);
// 
// 	m_sprdMccILog.SetRow(0);
// 
// 	m_sprdMccILog.SetCol(MCC_ILOG_COL_TIME);			m_sprdMccILog.SetColWidth(MEAS_RESULT_ICP_COL_NO, 14.0);	m_sprdMccILog.SetText(_T("EventTime"));
// 	m_sprdMccILog.SetCol(MCC_ILOG_COL_TYPE);			m_sprdMccILog.SetColWidth(MEAS_RESULT_ICP_CELL_ID, 6.0);	m_sprdMccILog.SetText(_T("LogType"));

	m_list_ILOG.DeleteAllItems(); 

	CFileFind finder;
	CString strMCCFile;
//	strMCCFile.Format("%s%s%s",m_strAppPath, STR_DIR_CONFIG,  MCC_NAME_FILE);
	strMCCFile = GetCnfPath(m_pMCCMap->nEQType, MCC_NAME_FILE);		// jsyoon 20170529 change
	if (finder.FindFile(strMCCFile) == FALSE)
	{
		CString str ;
		str.Format(_T("Can not fined '%s'"), strMCCFile);
		AfxMessageBox(str);
		return 0;
	}

	TCHAR szTmp[100];
	TCHAR szCmd[60000];
	szTmp[0] = 0x00;
	szCmd[0] = 0x00;

	CString strLine, strFrom, strName, strValue, strLog;
	CStringArray strArray;
	CString strTemp;
	int lenTemp = 0, iCol = 0;

	strLog.Empty();
	strLog.Format(_T("EventTime, LogType"));


	strValue.Format(_T("EventTime,"));
	_stprintf_s(szTmp, _countof(szTmp), _T("%s"), strValue);	_tcscat_s(szCmd, _countof(szCmd), szTmp); 

	strValue.Format(_T("LogType,"));
	_stprintf_s(szTmp, _countof(szTmp), _T("%s"), strValue);	_tcscat_s(szCmd, _countof(szCmd), szTmp); 


	CStdioFile File(strMCCFile, CFile::modeRead);

	CStringArray strAry;
	strAry.RemoveAll();
	do 
	{
		if (File.ReadString(strLine))
		{
			int iStart = 0;
			int iEnd   = 0;
			bool bToggle = TRUE;

			strArray.RemoveAll();

			lenTemp = strLine.GetLength();
			for(int i = 0 ; i < lenTemp; i++)
			{		
				if(bToggle)
				{
					iStart = i;
					bToggle = FALSE;
				}

				if(strLine.GetAt(i) == ',')
				{
					bToggle = TRUE;
					iEnd = i;
					iEnd -= iStart;

					strTemp = strLine.Mid(iStart, iEnd);
					strArray.Add(strTemp);
				}
				else if( i == lenTemp-1 )
				{
					iEnd = i;
					iEnd -= iStart;

					strTemp = strLine.Mid(iStart, iEnd+1);
					strArray.Add(strTemp);
				}
			}

			if( strArray.GetSize() > 0 )
			{
				strName = strArray.GetAt(0);
				strName.TrimRight();

				if( strArray.GetSize() > 1 )
				{
					strFrom = strArray.GetAt(1);
					strFrom.TrimRight();
				}
				else
				{
	//				strFrom = _T("ICPU");
					strFrom.Format(_T("%s"), m_pMCCMap->stMCCInfoEQ.szModuleID);		// ModuleID=Para Name1
				}

				strValue.Format(_T("%s=%s"), strFrom, strName); 

				strAry.Add(strValue);

//				strLog += strValue; 
// 				m_sprdMccILog.SetCol(MCC_ILOG_COL_ITEM+iCol);
// 				m_sprdMccILog.SetColWidth(MCC_ILOG_COL_ITEM, 8.0);
// 				m_sprdMccILog.SetText(strValue);
				iCol++;
			}
		}
		else				// End file
		{
			break;
		}
	} while (TRUE);

	File.Close(); 

	int nLoop = strAry.GetSize();
	for (int iLoop = 0; iLoop<nLoop; iLoop++)
	{
		if( iLoop + 1 == nLoop)
			strValue.Format(_T("%s"), strAry.GetAt(iLoop));
		else
			strValue.Format(_T("%s,"), strAry.GetAt(iLoop));

		_stprintf_s(szTmp, _countof(szTmp), _T("%s"), strValue);	_tcscat_s(szCmd, _countof(szCmd), szTmp); 
	}

	int n = _tcsclen(szCmd);				
	szCmd[n] = 0;			
	CString strILog;
	strILog.Format(_T("%s"), szCmd);

	ILOG(strILog);
	ILOG(_T(""));

//	m_sprdMccILog.SetMaxCols(iCol+2);

	return 0;
}


int CDlgnMCCReport::UpdateMCCInfo(int iRow)
{
//	m_sprdMccILog.SetMaxRows(iRow+1);

//	CString  strValue;
//	m_sprdMccILog.SetRow(iRow+1);

//	strValue.Format(_T("%s"), gf_MakeCurTimeString());
//	m_sprdMccILog.SetCol(MCC_ILOG_COL_TIME);
//	m_sprdMccILog.SetValue(strValue);

//	strValue.Format(_T("I"));
//	m_sprdMccILog.SetCol(MCC_ILOG_COL_TYPE);
//	m_sprdMccILog.SetValue(strValue);

// 	int iCol = 0;
// 	int iAxis = 0;
// 	int iUpdata[30] = {AXIS_X,AXIS_Y,AXIS_R,AXIS_LOADER_X, AXIS_LOADER_Y,AXIS_LOADER_Z,AXIS_LP,AXIS_LOADER_R,AXIS_X2,AXIS_Y1,AXIS_Y2,AXIS_Z,AXIS_Z3,AXIS_ZOOM1,AXIS_ZOOM2,AXIS_THETA1,AXIS_THETA2,AXIS_Z2,AXIS_Z5,AXIS_FOCUS1,AXIS_FOCUS2,AXIS_ROTATE1,AXIS_ROTATE2,AXIS_Z1,AXIS_Z4,AXIS_Y3,AXIS_Y4,AXIS_Y5,AXIS_Y6, AXIS_UNIT_Z};
// 	for (int iLoop = 0; iLoop<30; iLoop++)
// 	{
// 		iAxis = iUpdata[iLoop];
// 
// 		if(iAxis == AXIS_X1 || iAxis == AXIS_X3 || iAxis ==  AXIS_LP2 || iAxis ==  AXIS_Z9 || iAxis == AXIS_FILTER1 || iAxis == AXIS_FILTER2 || iAxis ==  AXIS_X4 || iAxis == AXIS_X5 || iAxis ==  AXIS_Z9
// 			|| iAxis == AXIS_Y7 || iAxis == AXIS_Y8 || iAxis == AXIS_R1 || iAxis == AXIS_R2 || iAxis == AXIS_Z6 || iAxis == AXIS_Z7 || iAxis == AXIS_UNIT_Z2)
// 			continue;
// 
// 		strValue.Format(_T("%.3f"), m_pMCCMap->stMCCDataEQ.stMoterInfo[iAxis].dSetAxisSpeed);
// 		m_sprdMccILog.SetCol(MCC_ILOG_COL_ITEM+iCol);
// 		m_sprdMccILog.SetValue(strValue);
// 		iCol++;
// 		strValue.Format(_T("%.3f"), m_pMCCMap->stMCCDataEQ.stMoterInfo[iAxis].dSetAxisPos);
// 		m_sprdMccILog.SetCol(MCC_ILOG_COL_ITEM+iCol);
// 		m_sprdMccILog.SetValue(strValue);
// 		iCol++;
// 		strValue.Format(_T("%.3f"), m_pMCCMap->stMCCDataEQ.stMoterInfo[iAxis].dAxisSpeed);
// 		m_sprdMccILog.SetCol(MCC_ILOG_COL_ITEM+iCol);
// 		m_sprdMccILog.SetValue(strValue);
// 		iCol++;
// 		strValue.Format(_T("%.3f"), m_pMCCMap->stMCCDataEQ.stMoterInfo[iAxis].dAxisPos);
// 		m_sprdMccILog.SetCol(MCC_ILOG_COL_ITEM+iCol);
// 		m_sprdMccILog.SetValue(strValue);
// 		iCol++;
// 		strValue.Format(_T("%.3f"), m_pMCCMap->stMCCDataEQ.stMoterInfo[iAxis].dAxisRMS);
// 		m_sprdMccILog.SetCol(MCC_ILOG_COL_ITEM+iCol);
// 		m_sprdMccILog.SetValue(strValue);
// 		iCol++;
// 	}
// 
// 	int iTem = 0;
// 	for (iTem = 0; iTem<MCC_ILOG_COL_ITEM2_E-MCC_ILOG_COL_ITEM2; iTem++)
// 	{
// 		strValue.Format(_T("%.3f"), m_pMCCMap->stMCCDataEQ.dData[iTem]);
// 		m_sprdMccILog.SetCol(MCC_ILOG_COL_ITEM2+iTem);
// 		m_sprdMccILog.SetValue(strValue);
// 	}

	return 0;
}

int CDlgnMCCReport::UpdateMCCTLog(void)
{
	MCC_EQDATA_T stMCCData;
	ZeroMemory(&stMCCData, sizeof(stMCCData));

	do 
	{
		if( DeleteQueue(&stMCCData) == 1)
//		if( m_queue.DeleteQueue(&stMCCData) == 1)
		{
			int EvtFlag = 0, iEvn = 0, nStep = 0, nFromto;
			BOOL bStart = FALSE;
			CString str;
			EvtFlag = stMCCData.iEvtFlag;
			iEvn = stMCCData.iSpqNum;
			bStart = stMCCData.bFlagStoE;
			nStep = stMCCData.iStepNum;
			nFromto = stMCCData.iFromto;
			str.Format(_T("%s"), stMCCData.m_szEvtTime);
			TRACE("Queue %d, %d, %d \n", EvtFlag, iEvn, bStart);

			switch (EvtFlag)
			{
			case 0:
//				WriteMCCAction(str,iEvn, bStart);
				WriteMCCAction(str,iEvn, bStart, nStep, nFromto);
				break;
			case 1:
				WriteMCCSignal(str,iEvn, bStart);
				break;
			case 2:
				WriteMCCError(str,iEvn, bStart);
				break;
			case 3:
				WriteMCCWarring(str,iEvn, bStart);
				break;
			default:
				break;
			}
		}

	} while (IsEmpty() != true);

	return 0;
}

// ��ü ������
MyQueue::MyQueue()
{
	// �ɹ� ������ �ʱ�ȭ
	m_rear = 0;
	m_front = 0;
}

// ť�� Full �� ��� 1 �� ��ȯ�ϴ� ����Լ�
// �ƴ� ��� 0 �� ��ȯ
bool MyQueue::IsFull()
{
	if ((m_rear + 1) % MAX_QUEUE_COUNT == m_front) 
	{
		return true; // ť�� Full �� ���
	}
	else 
	{
		return false; // Full �� �ƴ� ���
	}
}

// ť�� �� ��� 1�� ��ȯ�ϴ� �Լ�
// ť�� �ڷᰡ �����ϴ� ��� 0 �� ��ȯ
bool MyQueue::IsEmpty()
{
	if (m_rear == m_front) 
	{
		return true; // Empty �� ���
	}
	// ť�� �ڷᰡ �����ϴ� ���
	else 
	{
		return false;
	}
}

// ť�� parm_temp �ڷḦ �����ϴ� ����Լ�
int MyQueue::AddQueue(MCC_EQDATA_T stData)
{
	if (false == IsFull()){
		// Rear �� ���� �ε����� ���� ����
		// 0 ~ 100 ���� ������ ��  100 ���� �ٽ� 0 ���� �ʱ�ȭ
		m_rear = (m_rear + 1) % MAX_QUEUE_COUNT;

		// ť�� �������� �����͸� �߰�
		m_queue_data[m_rear] = stData;

		return 1;
	}
	// ���� �������� ���� ���
	return 0;
}

// ť�� �ڷḦ �����ϴ� ����Լ�
// ���ڷ� �Ѿ�� parm_temp �� �ּҿ� ó���� �ڷḦ ����
int MyQueue::DeleteQueue(PMCC_EQDATA_T pstData)
{
	if (false == IsEmpty()){
		// Front ���� ���� �ε����� ���� 
		// 0 ~ 100 ���� ������ ��  100 ���� �ٽ� 0 ���� �ʱ�ȭ
		m_front = (m_front + 1) % MAX_QUEUE_COUNT;

		// ť�� ���ο� �ִ� �ڷḦ parm_p_value �� ����
		*pstData = m_queue_data[m_front];

		memset (&m_queue_data[m_front], 0x00, sizeof(MCC_EQDATA));
		return 1;
	}
	// ť�� Empty �� ��� 0 �� ��ȯ
	return 0;
}



int CDlgnMCCReport::AddMccQueue(int iFlag)
{
	MCC_EQDATA_T stMCCData;
	ZeroMemory(&stMCCData, sizeof(stMCCData));
	stMCCData = m_pMCCMap->stMCCDataEQ;
	_tcscpy_s(stMCCData.m_szEvtTime, _countof(stMCCData.m_szEvtTime), gf_MakeCurTimeString());

	m_queue.AddQueue(stMCCData);
	return 0;
}


int CDlgnMCCReport::UpdateMCCILOG(void)
{
	CString strValue, strILog;
	TCHAR szTmp[100];
	TCHAR szCmd[60000];
	szTmp[0] = 0x00;
	szCmd[0] = 0x00;


	strValue.Format(_T("%s,"), gf_MakeCurTimeString());
	_stprintf_s(szTmp, _countof(szTmp), _T("%s"), strValue);	_tcscat_s(szCmd, _countof(szCmd), szTmp); 

	strValue.Format(_T("I,"));
	_stprintf_s(szTmp, _countof(szTmp), _T("%s"), strValue);	_tcscat_s(szCmd, _countof(szCmd), szTmp); 
		
	int iCol = 0;
	int iAxis = 0;
	int iLoop = 0;
	int nLoop = 0;

//	int iUpdata[30] = {AXIS_X,AXIS_Y,AXIS_R,AXIS_LOADER_X, AXIS_LOADER_Y,AXIS_LOADER_Z,AXIS_LP,AXIS_LOADER_R,AXIS_X2,AXIS_Y1,AXIS_Y2,AXIS_Z,AXIS_Z3,AXIS_ZOOM1,AXIS_ZOOM2,AXIS_THETA1,AXIS_THETA2,AXIS_Z2,AXIS_Z5,AXIS_FOCUS1,AXIS_FOCUS2,AXIS_ROTATE1,AXIS_ROTATE2,AXIS_Z1,AXIS_Z4,AXIS_Y3,AXIS_Y4,AXIS_Y5,AXIS_Y6, AXIS_UNIT_Z};
	for (iLoop = 0; iLoop<100; iLoop++)
	{
// 		if(	m_pMCCMap->nEQType == EQU_TYPE_ICP )
// 		{
// 			nLoop = 30;
// 
// 			if( iLoop < nLoop)
// 			{
// 				int iUpdata[30] = {AXIS_X,AXIS_Y,AXIS_R,AXIS_LOADER_X, AXIS_LOADER_Y,AXIS_LOADER_Z,AXIS_LP,AXIS_LOADER_R,AXIS_X2,AXIS_Y1,AXIS_Y2,AXIS_Z,AXIS_Z3,AXIS_ZOOM1,AXIS_ZOOM2,AXIS_THETA1,AXIS_THETA2,AXIS_Z2,AXIS_Z5,AXIS_FOCUS1,AXIS_FOCUS2,AXIS_ROTATE1,AXIS_ROTATE2,AXIS_Z1,AXIS_Z4,AXIS_Y3,AXIS_Y4,AXIS_Y5,AXIS_Y6, AXIS_UNIT_Z};
// 				iAxis = iUpdata[iLoop];	
// 			}
// 			else
// 			{
// 				continue;
// 			}
// 
// 			
// 		}
// 		else if( m_pMCCMap->nEQType == EQU_TYPE_ICE )
// 		{
// 			nLoop = 16;
// 
// 			if( iLoop < nLoop)
// 			{
// 				int iUpdata[16] = {AXIS_X,AXIS_LOADER_X, AXIS_LOADER_Y,AXIS_LOADER_Z,AXIS_LP,AXIS_LOADER_R, AXIS_Y, AXIS_Z11, AXIS_XS, AXIS_XS2, AXIS_Y7, AXIS_Y8, AXIS_Z7, AXIS_Z8, AXIS_L,AXIS_L2};
// 				iAxis = iUpdata[iLoop];
// 			}
// 			else
// 			{
// 				continue;
// 			}
// 		}
// 		else if( m_pMCCMap->nEQType == EQU_TYPE_OCP )
// 		{
// 			nLoop = 38;
// 
// 			if( iLoop < nLoop)
// 			{
// 				int iUpdata[38] = {AXIS_X,AXIS_Y,AXIS_R,AXIS_LOADER_Z, AXIS_X4, AXIS_UNIT_Z, AXIS_R2, AXIS_X2, 
// 								   AXIS_Y1,AXIS_Y2,
// 								   AXIS_Z1,AXIS_Z4,AXIS_ZOOM1,AXIS_ZOOM2,AXIS_THETA1,AXIS_THETA2,AXIS_FILTER1, AXIS_FILTER2,
// 								   AXIS_Z3,AXIS_Z6,AXIS_FOCUS1,AXIS_FOCUS2,AXIS_ROTATE1,AXIS_ROTATE2,
// 								   AXIS_Z2,AXIS_Z5,
// 								   AXIS_Y7,AXIS_Y8,AXIS_Z7,AXIS_Z8, AXIS_L, AXIS_L2, AXIS_XS, AXIS_XS2, AXIS_WL1,AXIS_WL2, AXIS_UL1, AXIS_UL2};
// 				iAxis = iUpdata[iLoop];
// 			}
// 			else
// 			{
// 				continue;
// 			}
// 		}

		iAxis = iLoop;
		if (m_pMCCMap->stMCCDataEQ_ILog.stMoterInfo[iAxis].bUse != TRUE)
			continue;
					
		strValue.Format(_T("%.3f,"), m_pMCCMap->stMCCDataEQ_ILog.stMoterInfo[iAxis].dSetAxisSpeed);
		_stprintf_s(szTmp, _countof(szTmp), _T("%s"), strValue);	_tcscat_s(szCmd, _countof(szCmd), szTmp); 

		strValue.Format(_T("%.3f,"), m_pMCCMap->stMCCDataEQ_ILog.stMoterInfo[iAxis].dSetAxisPos);
		_stprintf_s(szTmp, _countof(szTmp), _T("%s"), strValue);	_tcscat_s(szCmd, _countof(szCmd), szTmp); 
		
		strValue.Format(_T("%.3f,"), m_pMCCMap->stMCCDataEQ_ILog.stMoterInfo[iAxis].dAxisSpeed);
		_stprintf_s(szTmp, _countof(szTmp), _T("%s"), strValue);	_tcscat_s(szCmd, _countof(szCmd), szTmp); 

		strValue.Format(_T("%.3f,"), m_pMCCMap->stMCCDataEQ_ILog.stMoterInfo[iAxis].dAxisPos);
		_stprintf_s(szTmp, _countof(szTmp), _T("%s"), strValue);	_tcscat_s(szCmd, _countof(szCmd), szTmp); 

		strValue.Format(_T("%.3f,"), m_pMCCMap->stMCCDataEQ_ILog.stMoterInfo[iAxis].dAxisRMS);
		_stprintf_s(szTmp, _countof(szTmp), _T("%s"), strValue);	_tcscat_s(szCmd, _countof(szCmd), szTmp); 
	}

	nLoop = m_pMCCMap->stMCCDataEQ_ILog.nCntILog;

// 	if( m_pMCCMap->nEQType == EQU_TYPE_ICP )
// 		nLoop = 17;
// 	else if( m_pMCCMap->nEQType == EQU_TYPE_ICE )
// 		nLoop = 17;


	for (iLoop = 0; iLoop<nLoop; iLoop++)
	{
		if( iLoop + 1 == nLoop)
			strValue.Format(_T("%.3f"), m_pMCCMap->stMCCDataEQ_ILog.dData[iLoop]);
		else
			strValue.Format(_T("%.3f,"), m_pMCCMap->stMCCDataEQ_ILog.dData[iLoop]);

		_stprintf_s(szTmp, _countof(szTmp), _T("%s"), strValue);	_tcscat_s(szCmd, _countof(szCmd), szTmp); 
	}

// 	for (iLoop = 0; iLoop<MCC_ILOG_COL_ITEM2_E-MCC_ILOG_COL_ITEM2; iLoop++)
// 	{
// 		if( iLoop + 1 == MCC_ILOG_COL_ITEM2_E-MCC_ILOG_COL_ITEM2)
// 			strValue.Format("%.3f", m_pSystem->m_stMccData.dData[iLoop]);
// 		else
// 			strValue.Format("%.3f,", m_pSystem->m_stMccData.dData[iLoop]);
// 
// 		_stprintf_s(szTmp, _countof(szTmp), "%s", strValue);	_tcscat_s(szCmd, _countof(szCmd), szTmp); 
// 	}

	int n = _tcsclen(szCmd);				
	szCmd[n] = 0;			

	strILog.Format(_T("%s"), szCmd);
	ILOG(strILog);

	return 0;
}


void CDlgnMCCReport::OnBnClickedCheckT()
{
	UpdateData(FALSE);

	m_bMccTransferOn = (BOOL)m_chkUseSend.GetCheck();

	if( m_pMCCMap != nullptr)
	{
		m_pMCCMap->bMCCTransfer = m_bMccTransferOn;
	}
}


void CDlgnMCCReport::OnSize(UINT nType, int cx, int cy)
{
	CDialog::OnSize(nType, cx, cy);

	// TODO: Add your message handler code here
	if(m_bInitDialog == true)
	{
		CRect rect, rect2;
		m_list_TLOG.GetWindowRect(rect);
		ScreenToClient(&rect);
		m_list_TLOG.MoveWindow(0,rect.top, cx, rect.Height());

		m_list_ILOG.GetWindowRect(rect2);
		ScreenToClient(&rect2);
		m_list_ILOG.MoveWindow(0,rect2.top, cx, rect2.Height());
	}
}

void CDlgnMCCReport::Clear()
{
	m_pMCCMap->m_front = 0;
	m_pMCCMap->m_rear = 0;
}

// ť�� Full �� ��� 1 �� ��ȯ�ϴ� ����Լ�
// �ƴ� ��� 0 �� ��ȯ
bool CDlgnMCCReport::IsFull()
{
	if ((m_pMCCMap->m_rear + 1) % MAX_QUEUE_COUNT == m_pMCCMap->m_front)
	{
		return true; // ť�� Full �� ���
	}
	else
	{
		return false; // Full �� �ƴ� ���
	}
}

// ť�� �� ��� 1�� ��ȯ�ϴ� �Լ�
// ť�� �ڷᰡ �����ϴ� ��� 0 �� ��ȯ
bool CDlgnMCCReport::IsEmpty()
{
	if (m_pMCCMap->m_rear == m_pMCCMap->m_front)
	{
		return true; // Empty �� ���
	}
	// ť�� �ڷᰡ �����ϴ� ���
	else
	{
		return false;
	}
}

// ť�� parm_temp �ڷḦ �����ϴ� ����Լ�
int CDlgnMCCReport::AddQueue(MCC_EQDATA_T stData)
{
	int nRear = 0;
	if (false == IsFull()) {
		// Rear �� ���� �ε����� ���� ����
		// 0 ~ 100 ���� ������ ��  100 ���� �ٽ� 0 ���� �ʱ�ȭ
		m_pMCCMap->m_rear = (m_pMCCMap->m_rear + 1) % MAX_QUEUE_COUNT;

		nRear = m_pMCCMap->m_rear;

		// ť�� �������� �����͸� �߰�
		m_pMCCMap->m_queue_data[nRear] = stData;

		return 1;
	}
	// ���� �������� ���� ���
	return 0;
}

// ť�� �ڷḦ �����ϴ� ����Լ�
// ���ڷ� �Ѿ�� parm_temp �� �ּҿ� ó���� �ڷḦ ����
int CDlgnMCCReport::DeleteQueue(PMCC_EQDATA_T pstData)
{
	int nfront = 0;
	if (false == IsEmpty()) {
		// Front ���� ���� �ε����� ���� 
		// 0 ~ 100 ���� ������ ��  100 ���� �ٽ� 0 ���� �ʱ�ȭ
		m_pMCCMap->m_front = (m_pMCCMap->m_front + 1) % MAX_QUEUE_COUNT;
		nfront = m_pMCCMap->m_front;

		// ť�� ���ο� �ִ� �ڷḦ parm_p_value �� ����
		*pstData = m_pMCCMap->m_queue_data[nfront];

		memset(&m_pMCCMap->m_queue_data[nfront], 0x00, sizeof(PMCC_EQDATA_T));
		return 1;
	}
	// ť�� Empty �� ��� 0 �� ��ȯ
	return 0;
}